#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#include "admin.h"



#define SE_OBTUVO_UN_ELEMENTO 1
#define UN_ALUMNO 1
#define CADENAS_SON_IGUALES 0
#define MEJOR_ALUMNO_GRYFFINDOR 0
#define MEJOR_ALUMNO_HUFFLEPUFF 1
#define MEJOR_ALUMNO_RAVENCLAW 2
#define MEJOR_ALUMNO_SLYTHERIN 3


typedef struct entrada_bitacora{
  char padron[MAXIMO_ELEMENTOS_PADRON];
  char fecha[MAXIMO_ELEMENTOS_FECHA];
  int puntos;
  char comentario[MAXIMO_ELEMENTOS_COMENTARIOS];
}entrada_bitacora_t;



bool pertenecen_a_la_misma_casa(alumno_t alumno1, alumno_t alumno2){

  bool tienen_la_misma_casa=false;

  if (!strcmp(alumno1.casa, alumno2.casa)) {
    tienen_la_misma_casa=true;
  }

  return tienen_la_misma_casa;
}


bool pertenecen_a_la_misma_casa_y_anio(alumno_t alumno1, alumno_t alumno2){

  bool tienen_la_misma_casa_y_anio=true;

  if (!pertenecen_a_la_misma_casa(alumno1, alumno2)) {
    tienen_la_misma_casa_y_anio=false;
  }

  if (alumno1.anio_de_cursada!=alumno2.anio_de_cursada) {
    tienen_la_misma_casa_y_anio=false;
  }

  return tienen_la_misma_casa_y_anio;

}



//precondiciones:-
//postcondiciones: si los puntos de la casa enviados son mayores que los de la casa
//que va ganando, le asigna a la casa ganadora el nombre de la casa evaluada

//cambiar nombre de la funcion a comparar casas?
void calcular_casa_ganadora(resumen_casa_t* casa_ganadora, unsigned long puntaje_casa, alumno_t alumno_anterior){

  if (puntaje_casa>(*casa_ganadora).puntos_casa) {
      strcpy((*casa_ganadora).casa, alumno_anterior.casa);
      (*casa_ganadora).puntos_casa=puntaje_casa;
  }

}



//precondiciones:-
//postcondiciones:introduce en la informacion de la casa ganadora el padron y los puntos del
//mejor alumno que pertenece a esa casa
void asignar_mejor_alumno(resumen_casa_t* casa_ganadora, alumno_t mejores_alumnos[CANTIDAD_CASAS]) {

  for (int i = 0; i < CANTIDAD_CASAS; i++) {

    if (!strcmp(mejores_alumnos[i].casa, (*casa_ganadora).casa)) {
      strcpy((*casa_ganadora).padron, mejores_alumnos[i].padron);
      (*casa_ganadora).puntos_alumno= (unsigned long)mejores_alumnos[i].puntos_obtenidos;
    }
  }


}


//precondiciones:-
//postcondiciones: introduce en el canal de impresion los valores de los
//atributos que posee la casa ganadora
void informar_sobre_casa_ganadora(FILE* canal_impresion, resumen_casa_t casa_ganadora){

  fprintf(canal_impresion, "La casa ganadora es: %s\n", casa_ganadora.casa);
  fprintf(canal_impresion, "Puntaje: %lu\n", casa_ganadora.puntos_casa);
  fprintf(canal_impresion, "Alumno con mayor puntaje de la casa: %s\n", casa_ganadora.padron);
  fprintf(canal_impresion, "Puntaje del alumno: %lu\n", casa_ganadora.puntos_alumno);
}


//precondicion: el alumno a copiar debe estar inicializado
//postcondicion: copia los contenidos del alumno a copiar en el
//alumno a modificar
void copiar_alumno(alumno_t* alumno_a_modificar, alumno_t alumno_a_copiar){
  strcpy((*alumno_a_modificar).padron, alumno_a_copiar.padron);
  strcpy((*alumno_a_modificar).nombre, alumno_a_copiar.nombre);
  strcpy((*alumno_a_modificar).casa, alumno_a_copiar.casa);
  (*alumno_a_modificar).anio_de_cursada=alumno_a_copiar.anio_de_cursada;
  (*alumno_a_modificar).puntos_obtenidos=alumno_a_copiar.puntos_obtenidos;
}

//precondiciones:-
//postcondiciones: si el alumno evaluado tiene mas puntos que el mejor alumno hasta el momento
//de la casa a la que pertenece, el alumno evaluado pasa a ser el mejor alumno de su casa
void calcular_mejor_alumno(alumno_t mejores_alumnos[CANTIDAD_CASAS], alumno_t alumno_leido){

  for (int i = 0; i < CANTIDAD_CASAS; i++) {
      if (!strcmp(mejores_alumnos[i].casa, alumno_leido.casa)) {
          if (mejores_alumnos[i].puntos_obtenidos< alumno_leido.puntos_obtenidos) {
            copiar_alumno(&(mejores_alumnos[i]),alumno_leido);
          }
      }
  }

}


//precondiciones: la direccion del archivo a eliminar debe ser valida
//poscondiciones: elimina el archivo que se encuentra en la direccion indicada
//e indica si hubo un error al hacerlo
bool eliminar_archivo(char ruta_archivo_a_eliminar[]){

  bool se_elimino_archivo=false;

  if (!remove(ruta_archivo_a_eliminar)) {
    se_elimino_archivo=true;
  }

  return se_elimino_archivo;
}


//precondiciones: las rutas enviadas deben ser validas
//postcondiciones: cambia la ruta del archivo a la deseada e indica si
//hubo un error al hacerlo
bool renombrar_archivo(char ruta_vieja[], char ruta_nueva[]){

  bool se_renombro_archivo=false;

  if (!rename(ruta_vieja, ruta_nueva)) {
    se_renombro_archivo=true;
  }

  return se_renombro_archivo;
}


//bool remplazar archivo

//precondiciones: el archivo del cual se quiere obtener un alumno debe existir y sus contenidos
//deben ser variables del tipo alumno_t
//postcondiciones: indica si se pudo leer un alumno y si se da el caso introduce en la variable
//pasada el alumno leido del archivo
bool obtener_alumno(FILE* archivo, alumno_t* alumno_a_obtener){

  int se_obtuvo_alumno=true;
  int cantidad_elementos_obtenidos;

  cantidad_elementos_obtenidos=(int)fread(alumno_a_obtener, sizeof(alumno_t), UN_ALUMNO, archivo);

  if (cantidad_elementos_obtenidos!=UN_ALUMNO) {
    se_obtuvo_alumno=false;
  }
  return se_obtuvo_alumno;
}

//borrar?
bool introducir_alumno(FILE* archivo, alumno_t* alumno_a_inscribir){

  int se_inscribio_alumno=true;
  int cantidad_elementos_inscriptos;

  cantidad_elementos_inscriptos=(int)fwrite(alumno_a_inscribir, sizeof(alumno_t), UN_ALUMNO, archivo);

  if (cantidad_elementos_inscriptos!=UN_ALUMNO) {
    se_inscribio_alumno=false;
  }
  return se_inscribio_alumno;
}


//agregar pre y postcondiciones
int pasar_de_anio(char* ruta_origen, char* ruta_destino){

  bool se_obtuvo_alumno;
  alumno_t alumno_auxiliar;
  int contador_alumnos_pasados=0;
  //int estado_archivos;


  FILE* informacion_vieja_alumnos=fopen(ruta_origen, "r");

  if (!informacion_vieja_alumnos) {
    //return NO_SE_ABRIO_EL_PRIMER_ARCHIVO;
    //return NO_SE_ABRIO_EL_PRIMER_ARCHIVO;
    informacion_vieja_alumnos=fopen(ruta_origen, "w");
    fclose(informacion_vieja_alumnos);
    informacion_vieja_alumnos=fopen(ruta_origen, "r");
  }

  FILE* alumnos_con_anio_actualizado=fopen(ruta_destino, "w");

  if (!alumnos_con_anio_actualizado) {
    fclose(informacion_vieja_alumnos);
    return NO_SE_ABRIO_EL_SEGUNDO_ARCHIVO;
  }


  se_obtuvo_alumno=obtener_alumno(informacion_vieja_alumnos, &alumno_auxiliar);

  //cambiar a chequear si se leyo un elemento
  while (/*!feof(informacion_vieja_alumnos)*/se_obtuvo_alumno) {
    //pasar a funcion
    //revisar código para ver si funciona como se espera

    alumno_auxiliar.anio_de_cursada++;


    //ver si el if tiene que ir en la funcion que va a introducir los alumnos en el
    //archivo limpio
    if (alumno_auxiliar.anio_de_cursada<=CANTIDAD_ANIOS_DE_CURSADA) {
      alumno_auxiliar.puntos_obtenidos=NO_TIENE_PUNTOS;
      //introducir_alumno?
      fwrite(&alumno_auxiliar, sizeof(alumno_t), UN_ALUMNO, alumnos_con_anio_actualizado);
      contador_alumnos_pasados++;
    }

    se_obtuvo_alumno=obtener_alumno(informacion_vieja_alumnos, &alumno_auxiliar);

    /*
    if (obtener_alumno(informacion_vieja_alumnos, &alumno_auxiliar)==SE_OBTUVO_UN_ELEMENTO) {
      alumno_auxiliar.anio_de_cursada++;

      if (alumno_auxiliar.anio_de_cursada<=CANTIDAD_ANIOS_DE_CURSADA) {
        alumno_auxiliar.puntos_obtenidos=NO_TIENE_PUNTOS;
        fwrite(&alumno_auxiliar, sizeof(alumno_t), UN_ALUMNO, alumnos_con_anio_actualizado);
        contador_alumnos_pasados++;
      }
    }

    */
  }


  fclose(informacion_vieja_alumnos);
  fclose(alumnos_con_anio_actualizado);

  return contador_alumnos_pasados;
}




//agregar pre y postcondiciones
//PONER TODOS LOS RETURNS DESPUES DEL FCLOSE
int actualizar_alumnos(char* ruta_alumnos, char* ruta_actualizaciones){


  //cambiar alumno_anterior por alumno_leido o alumno_ya_inscripto
  alumno_t alumno_ya_inscripto;
  //alumno_t alumno_actual;
  alumno_t alumno_a_inscribir;

  int elementos_obtenidos=0;
  int alumnos_introducidos=0;
  int se_obtuvo_alumno=0;


  FILE* alumnos=fopen(ruta_alumnos, "r");

  if (!alumnos){
    //return NO_SE_ABRIO_EL_PRIMER_ARCHIVO;
    alumnos=fopen(ruta_alumnos, "w");
    fclose(alumnos);
    alumnos=fopen(ruta_alumnos, "r");
  }

  FILE* ingresos=fopen(ruta_actualizaciones, "r");

  if (!ingresos){
    fclose(alumnos);
    return NO_SE_ABRIO_EL_SEGUNDO_ARCHIVO;
  }

  FILE* nuevo_alumnos=fopen(AUXILIAR_ALUMNOS, "w");

  if (!nuevo_alumnos) {
    fclose(alumnos);
    fclose(ingresos);
    return NO_SE_CREO_EL_ARCHIVO;
  }


  elementos_obtenidos=fscanf(ingresos, FORMATO_INGRESOS, alumno_a_inscribir.padron, alumno_a_inscribir.nombre, alumno_a_inscribir.casa, &(alumno_a_inscribir.anio_de_cursada));

  //alumno_a_introducir.puntos_obtenidos=NO_TIENE_PUNTOS;

  se_obtuvo_alumno=obtener_alumno(alumnos,&alumno_ya_inscripto);

//AGREGAR OPERACION CON LOS ULTIMOS ELEMENTOS DESPUES DE LOS WHILES
//Cambiar alumno_anterior por alumno_ya_inscripto


  while ((elementos_obtenidos==ELEMENTOS_POR_ALUMNO_NUEVO)&&(se_obtuvo_alumno)/*&&(!feof(ingresos))&&(!feof(alumnos))*/) {


    //ver si se remplaza el CADENAS_SON_IGUALES por un !strcmp
      while ((/*strcmp(alumno_anterior.casa, alumno_a_introducir.casa)==CADENAS_SON_IGUALES*/pertenecen_a_la_misma_casa(alumno_ya_inscripto, alumno_a_inscribir))&&(elementos_obtenidos==ELEMENTOS_POR_ALUMNO_NUEVO)&&(se_obtuvo_alumno)/*&&(!feof(ingresos))&&(!feof(alumnos))*/) {

        //combinar los whiles en uno solo???
        //
        while ((pertenecen_a_la_misma_casa_y_anio(alumno_ya_inscripto, alumno_a_inscribir))/*(alumno_anterior.anio_de_cursada==alumno_a_introducir.anio_de_cursada)&&(strcmp(alumno_anterior.casa, alumno_a_introducir.casa)==CADENAS_SON_IGUALES)*/&&(elementos_obtenidos==ELEMENTOS_POR_ALUMNO_NUEVO)&&(se_obtuvo_alumno)/*&&(!feof(ingresos))&&(!feof(alumnos))*/) {

          if (strcmp(alumno_ya_inscripto.padron, alumno_a_inscribir.padron)<CADENAS_SON_IGUALES) {

            //if(introducir_alumno) alumnos_introducidos++
            /*
            if (introducir_alumno(nuevo_alumnos, &alumno_anterior)!=OPERACION_EXITOSA) {
              return NO_SE_INSCRIBIO_ELEMENTO;
            }
            */

            introducir_alumno(nuevo_alumnos, &alumno_ya_inscripto);

              //alumnos_introducidos++;

            se_obtuvo_alumno=obtener_alumno(alumnos, &alumno_ya_inscripto);

          }else if(strcmp(alumno_ya_inscripto.padron, alumno_a_inscribir.padron)>CADENAS_SON_IGUALES){

            /*
            if (introducir_alumno(nuevo_alumnos, &alumno_a_introducir)!=OPERACION_EXITOSA) {
              return NO_SE_INSCRIBIO_ELEMENTO;
            }
            */

            alumno_a_inscribir.puntos_obtenidos=NO_TIENE_PUNTOS;
            introducir_alumno(nuevo_alumnos, &alumno_a_inscribir);

            alumnos_introducidos++;

            elementos_obtenidos=fscanf(ingresos, FORMATO_INGRESOS, alumno_a_inscribir.padron, alumno_a_inscribir.nombre, alumno_a_inscribir.casa, &(alumno_a_inscribir.anio_de_cursada));
          }

        }

        //pasar a funcion tal es menor que tal?
        while ((pertenecen_a_la_misma_casa(alumno_ya_inscripto, alumno_a_inscribir))&&(alumno_ya_inscripto.anio_de_cursada<alumno_a_inscribir.anio_de_cursada)/*strcmp(alumno_anterior.casa, alumno_a_introducir.casa)==CADENAS_SON_IGUALES)*//*&&(elementos_obtenidos==ELEMENTOS_POR_ALUMNO_NUEVO)*/&&(se_obtuvo_alumno)/*&&(!feof(ingresos))&&(!feof(alumnos))*/) {

          /*
          if (introducir_alumno(nuevo_alumnos, &alumno_anterior)!=OPERACION_EXITOSA) {
            return NO_SE_INSCRIBIO_ELEMENTO;
          }
          */

          introducir_alumno(nuevo_alumnos, &alumno_ya_inscripto);

          //alumnos_introducidos++;

          se_obtuvo_alumno=obtener_alumno(alumnos, &alumno_ya_inscripto);
        }


        while ((pertenecen_a_la_misma_casa(alumno_ya_inscripto, alumno_a_inscribir)/*strcmp(alumno_anterior.casa, alumno_a_introducir.casa)==CADENAS_SON_IGUALES*/)&&(alumno_ya_inscripto.anio_de_cursada>alumno_a_inscribir.anio_de_cursada)&&(elementos_obtenidos==ELEMENTOS_POR_ALUMNO_NUEVO)/*&&(se_obtuvo_alumno)*//*&&(!feof(ingresos))&&(!feof(alumnos))*/) {


          /*
          if (introducir_alumno(nuevo_alumnos, &alumno_a_introducir)!=OPERACION_EXITOSA) {
            return NO_SE_INSCRIBIO_ELEMENTO;
          }
          */
          alumno_a_inscribir.puntos_obtenidos=NO_TIENE_PUNTOS;
          introducir_alumno(nuevo_alumnos, &alumno_a_inscribir);

          alumnos_introducidos++;

          elementos_obtenidos=fscanf(ingresos, FORMATO_INGRESOS, alumno_a_inscribir.padron, alumno_a_inscribir.nombre, alumno_a_inscribir.casa, &(alumno_a_inscribir.anio_de_cursada));
        }

      }

      while ((strcmp(alumno_ya_inscripto.casa, alumno_a_inscribir.casa)<CADENAS_SON_IGUALES)&&/*(elementos_obtenidos==ELEMENTOS_POR_ALUMNO_NUEVO/&&*//*(!feof(ingresos))&&(!feof(alumnos))&&*/(se_obtuvo_alumno)) {

        /*
        if (introducir_alumno(nuevo_alumnos, &alumno_anterior)!=OPERACION_EXITOSA) {
          return NO_SE_INSCRIBIO_ELEMENTO;
        }
        */

        introducir_alumno(nuevo_alumnos, &alumno_ya_inscripto);

        //alumnos_introducidos++;

        se_obtuvo_alumno=obtener_alumno(alumnos, &alumno_ya_inscripto);
      }


      while ((strcmp(alumno_ya_inscripto.casa, alumno_a_inscribir.casa)>CADENAS_SON_IGUALES)&&(elementos_obtenidos==ELEMENTOS_POR_ALUMNO_NUEVO)/*&&(!feof(ingresos))&&(!feof(alumnos))*//*&&(se_obtuvo_alumno)*/) {

        /*
        if (introducir_alumno(nuevo_alumnos, &alumno_a_introducir)!=OPERACION_EXITOSA) {
          return NO_SE_INSCRIBIO_ELEMENTO;
        }

        */
        alumno_a_inscribir.puntos_obtenidos=NO_TIENE_PUNTOS;

        introducir_alumno(nuevo_alumnos, &alumno_a_inscribir);

        alumnos_introducidos++;

        elementos_obtenidos=fscanf(ingresos, FORMATO_INGRESOS, alumno_a_inscribir.padron, alumno_a_inscribir.nombre, alumno_a_inscribir.casa, &(alumno_a_inscribir.anio_de_cursada));
      }
  }


  while ((elementos_obtenidos==ELEMENTOS_POR_ALUMNO_NUEVO)/*&&(!feof(ingresos))*/) {


    /*
    if (introducir_alumno(nuevo_alumnos, &alumno_a_introducir)!=OPERACION_EXITOSA) {
      return NO_SE_INSCRIBIO_ELEMENTO;
    }

    */
    alumno_a_inscribir.puntos_obtenidos=NO_TIENE_PUNTOS;

    introducir_alumno(nuevo_alumnos, &alumno_a_inscribir);

    alumnos_introducidos++;

    elementos_obtenidos=fscanf(ingresos, FORMATO_INGRESOS, alumno_a_inscribir.padron, alumno_a_inscribir.nombre, alumno_a_inscribir.casa, &(alumno_a_inscribir.anio_de_cursada));

  }


  while ((se_obtuvo_alumno)/*&&(!feof(alumnos))*/) {


    /*
    if (introducir_alumno(nuevo_alumnos, &alumno_anterior)!=OPERACION_EXITOSA) {
      return NO_SE_INSCRIBIO_ELEMENTO;
    }

    */

    introducir_alumno(nuevo_alumnos, &alumno_ya_inscripto);

    //alumnos_introducidos++;

    //ver si obtener e inscribir alumno tiene que devolver un bool, sino este if es inutil
    se_obtuvo_alumno=obtener_alumno(alumnos, &alumno_ya_inscripto);

}

  fclose(alumnos);
  fclose(ingresos);
  fclose(nuevo_alumnos);


  //ver si se puede pasar a una funcion "remplazar archivo"
  if (!eliminar_archivo(ruta_alumnos)) {
      return NO_SE_ELIMINO_EL_ARCHIVO;
  }

  if (!renombrar_archivo(AUXILIAR_ALUMNOS, ruta_alumnos)) {
      return NO_SE_RENOMBRO_ARCHIVO;
  }


  return alumnos_introducidos;
}

/*if (alumno_a_introducir.anio_de_cursada==alumno_anterior.anio_de_cursada) {

if (strcmp(alumno_anterior.padron, alumno_a_introducir.padron)<CADENAS_SON_IGUALES) {
if (introducir_alumno(nuevo_alumnos, &alumno_anterior)!=OPERACION_EXITOSA) {
return NO_SE_INSCRIBIO_ELEMENTO;
}
}else if(strcmp(alumno_anterior.padron, alumno_a_introducir.padron)>CADENAS_SON_IGUALES){
if (introducir_alumno(nuevo_alumnos, &alumno_a_introducir)!=OPERACION_EXITOSA) {
return NO_SE_INSCRIBIO_ELEMENTO;
}
}
}
*/

//else if (strcmp(alumno_anterior.casa, alumno_a_introducir.casa)<CADENAS_SON_IGUALES) {




//agregar pre y postcondiciones
int aplicar(char* ruta_alumnos, char* ruta_bitacora){

  bool se_obtuvo_alumno;
  int elementos_obtenidos=0;
  alumno_t alumno_leido;
  entrada_bitacora_t alumno_a_actualizar;
  int bitacoras_procesadas=0;


  FILE* alumnos=fopen(ruta_alumnos, "r+");

  if (!alumnos){
    //return NO_SE_ABRIO_EL_PRIMER_ARCHIVO;
    //return NO_SE_ABRIO_EL_PRIMER_ARCHIVO;
    alumnos=fopen(ruta_alumnos, "w");
    fclose(alumnos);
    alumnos=fopen(ruta_alumnos, "r");
  }

  FILE* bitacora=fopen(ruta_bitacora, "r");

  if (!bitacora){
    fclose(alumnos);
    return NO_SE_ABRIO_EL_SEGUNDO_ARCHIVO;
  }

  /*

  elementos_obtenidos=fscanf(bitacora, FORMATO_BITACORA, alumno_a_actualizar.padron, alumno_a_actualizar.fecha, &(alumno_a_actualizar.puntos), alumno_a_actualizar.comentario);

  se_obtuvo_alumno=obtener_alumno(alumnos, &alumno_leido);


  while ((elementos_obtenidos==ELEMENTOS_POR_ENTRADA_BITACORA)&&(!feof(bitacora))) {

    //¿es necesario el !feof(alumnos)?
    while ((se_obtuvo_alumno)&&(!feof(alumnos))&&(strcmp(alumno_leido.padron, alumno_a_actualizar.padron)!=CADENAS_SON_IGUALES)) {
      se_obtuvo_alumno=obtener_alumno(alumnos, &alumno_leido);
    }

    alumno_leido.puntos_obtenidos+=alumno_a_actualizar.puntos;
    fseek(alumnos, -(long)sizeof(alumno_t), SEEK_CUR);
    introducir_alumno(alumnos, &alumno_leido);
    rewind(alumnos);
    bitacoras_procesadas++;
    elementos_obtenidos=fscanf(bitacora, FORMATO_BITACORA, alumno_a_actualizar.padron, alumno_a_actualizar.fecha, &(alumno_a_actualizar.puntos), alumno_a_actualizar.comentario);
  }

  */

/*
  while ((se_obtuvo_alumno)&&(!feof(alumnos))&&(strcmp(alumno_leido.padron, alumno_a_actualizar.padron)!=CADENAS_SON_IGUALES)) {
    se_obtuvo_alumno=obtener_alumno(alumnos, &alumno_leido);
  }

  alumno_leido.puntos_obtenidos+=alumno_a_actualizar.puntos;
  fseek(alumnos, -(long)sizeof(alumno_t), SEEK_CUR);
  introducir_alumno(alumnos, &alumno_leido);
  rewind(alumnos);
  bitacoras_procesadas++;
  elementos_obtenidos=fscanf(bitacora, FORMATO_BITACORA, alumno_a_actualizar.padron, alumno_a_actualizar.fecha, &(alumno_a_actualizar.puntos), alumno_a_actualizar.comentario);
*/


  //FILE* nuevo_alumnos=fopen(AUXILIAR_ALUMNOS, "w");

  se_obtuvo_alumno=obtener_alumno(alumnos, &alumno_leido);


  while ((se_obtuvo_alumno)/*&&(!feof(alumnos))*/) {

    elementos_obtenidos=fscanf(bitacora, FORMATO_BITACORA, alumno_a_actualizar.padron, alumno_a_actualizar.fecha, &(alumno_a_actualizar.puntos), alumno_a_actualizar.comentario);

    while ((elementos_obtenidos==ELEMENTOS_POR_ENTRADA_BITACORA)/*&&(!feof(bitacora))*/) {

      if (!strcmp(alumno_leido.padron, alumno_a_actualizar.padron)) {
        alumno_leido.puntos_obtenidos+=alumno_a_actualizar.puntos;
        bitacoras_procesadas++;
      }

      elementos_obtenidos=fscanf(bitacora, FORMATO_BITACORA, alumno_a_actualizar.padron, alumno_a_actualizar.fecha, &(alumno_a_actualizar.puntos), alumno_a_actualizar.comentario);
    }

    //alumno_leido
    //alumno_a_actualizar

    fseek(alumnos, -(long)sizeof(alumno_t), SEEK_CUR);
    introducir_alumno(alumnos, &alumno_leido);

    //introducir_alumno(nuevo_alumnos, &alumno_leido);
    se_obtuvo_alumno=obtener_alumno(alumnos, &alumno_leido);



    //cambiar el cerrado y la apertura del archivo por un rewind

    //fclose(bitacora);

  //bitacora=fopen(ruta_bitacora, "r");

    rewind(bitacora);
  }

  //se tiene que recorrer todo el archivo de bitacoras por cada
  //alumno del archivo alumnos para poder actualizarle los puntos


  fclose(alumnos);
  fclose(bitacora);


  //fclose(nuevo_alumnos);

  /*
  //ver si se puede pasar a una funcion "remplazar archivo"
  if (!eliminar_archivo(ruta_alumnos)) {
      return NO_SE_ELIMINO_EL_ARCHIVO;
  }

  if (!renombrar_archivo(AUXILIAR_ALUMNOS, ruta_alumnos)) {
      return NO_SE_RENOMBRO_ARCHIVO;
  }
  */

  //sacar el return para que compile
  return bitacoras_procesadas;
}






resumen_casa_t resumir_puntos(char* ruta_alumnos, FILE* canal_impresion){

  bool se_obtuvo_alumno=false;
  alumno_t alumno_leido;
  alumno_t alumno_anterior;


  //inicializar casas de mejores alumnos asi no da segmentation fault
  //la comparacion, o para que se haga bien la comparacion

  //vector de mejores alumnos ordenado alfabeticamente por casa ascendentemente
  alumno_t mejores_alumnos[CANTIDAD_CASAS];

  //hacer funcion "asignar_casas"
  //ver si conviene hacer un vector de strings e inicializar con un for
  strcpy(mejores_alumnos[MEJOR_ALUMNO_GRYFFINDOR].casa, "Gryffindor");
  strcpy(mejores_alumnos[MEJOR_ALUMNO_HUFFLEPUFF].casa, "Hufflepuff");
  strcpy(mejores_alumnos[MEJOR_ALUMNO_RAVENCLAW].casa, "Ravenclaw");
  strcpy(mejores_alumnos[MEJOR_ALUMNO_SLYTHERIN].casa, "Slytherin");



  resumen_casa_t casa_ganadora;
  int puntaje_casa=0;
  int puntaje_anio=0;

  casa_ganadora.puntos_casa=0;
  casa_ganadora.puntos_alumno=0;

  for (int i = 0; i < CANTIDAD_CASAS; i++) {
    mejores_alumnos[i].puntos_obtenidos=0;
  }


  FILE* alumnos=fopen(ruta_alumnos, "r");

  if (!alumnos) {
    //return NO_SE_ABRIO_EL_PRIMER_ARCHIVO;
    alumnos=fopen(ruta_alumnos, "w");
    fclose(alumnos);
    alumnos=fopen(ruta_alumnos, "r");
  }


  se_obtuvo_alumno=obtener_alumno(alumnos, &alumno_leido);

  copiar_alumno(&alumno_anterior, alumno_leido);


  while ((se_obtuvo_alumno)&&(!feof(alumnos))) {


    fprintf(canal_impresion, "%s:\n", alumno_leido.casa);

    copiar_alumno(&alumno_anterior, alumno_leido);


    while ((se_obtuvo_alumno)/*&&(!feof(alumnos))*/&&(!strcmp(alumno_anterior.casa, alumno_leido.casa))) {

      copiar_alumno(&alumno_anterior, alumno_leido);

      while ((se_obtuvo_alumno)/*&&(!feof(alumnos))*/&&(!strcmp(alumno_anterior.casa, alumno_leido.casa))&&(alumno_anterior.anio_de_cursada==alumno_leido.anio_de_cursada)) {




        /*
        for (int i = 0; i < CANTIDAD_CASAS; i++) {
            if (!strcmp(mejores_alumnos[i].casa, alumno_leido.casa)) {
                if (mejores_alumnos[i].puntos_obtenidos< alumno_leido.puntos_obtenidos) {
                  copiar_alumno(&(mejores_alumnos[i]),alumno_leido);
                }
            }
        }

        */

        calcular_mejor_alumno(mejores_alumnos, alumno_leido);


        puntaje_anio+=alumno_leido.puntos_obtenidos;

        copiar_alumno(&alumno_anterior, alumno_leido);
        //poner bien el momento en el q el alumno anterior se iguala al actual leido
        se_obtuvo_alumno=obtener_alumno(alumnos, &alumno_leido);
      }


      fprintf(canal_impresion, "El puntaje del anio %d es: %d\n", alumno_anterior.anio_de_cursada, puntaje_anio);
      puntaje_casa+=puntaje_anio;

      puntaje_anio=0;
    }
    //fprintf(canal_impresion, "El puntaje de la casa %s es: %d\n", alumno_anterior.casa, puntaje_casa);
    fprintf(canal_impresion, "El puntaje de la casa es: %d\n", puntaje_casa);


    /*
    if (puntaje_casa>casa_ganadora.puntos_casa) {
        strcpy(casa_ganadora.casa, alumno_anterior.casa);
        casa_ganadora.puntos_casa=(unsigned long)puntaje_casa;
    }*/


    //cambiar nombre de la funcion a comparar casas?
    calcular_casa_ganadora(&casa_ganadora, (unsigned long)puntaje_casa, alumno_anterior);


    /*
    for (int i = 0; i < CANTIDAD_CASAS; i++) {

      if (!strcmp(mejores_alumnos[i].casa, casa_ganadora.casa)) {
        strcpy(casa_ganadora.padron, mejores_alumnos[i].padron);
        casa_ganadora.puntos_alumno= (unsigned long)mejores_alumnos[i].puntos_obtenidos;
      }
    }
    */

    asignar_mejor_alumno(&casa_ganadora, mejores_alumnos);

    puntaje_casa=0;
  }

  informar_sobre_casa_ganadora(canal_impresion, casa_ganadora);

  fclose(alumnos);

  //ver como devolver un error en la funcion

  return casa_ganadora;
}
