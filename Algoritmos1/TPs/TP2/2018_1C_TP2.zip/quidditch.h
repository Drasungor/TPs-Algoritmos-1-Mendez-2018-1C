#ifndef QUIDDITCH_H
#define QUIDDITCH_H

/* ACA VAN LAS CONSTANTES */

typedef struct coordenada {
	int fila;
	int columna;
} coordenada_t;

typedef struct juego {
	coordenada_t posicion_jugador;
	char casa;
	int resistencia;
	coordenada_t posicion_snitch;

	int bludgers_en_juego; // tope del vector posicion_bludgers
	coordenada_t posicion_bludgers[/* UNA CONSTANTE */];
	char direccion; // 'D': derecha – 'I': izquierda

	int dementores_en_juego; // tope del vector posicion_dementores
	coordenada_t posicion_dementores[/* UNA CONSTANTE */];
	
	int estado; // 0: en ejecucion – 1: jugador gano – 2: jugador perdio
} juego_t;

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE inicializar_juego
 */
void inicializar_juego(char campo[/* UNA CONSTANTE */][/* UNA CONSTANTE */], char casa, juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
char pedir_movimiento(coordenada_t posicion_jugador);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
void mover_jugador(char campo[/* UNA CONSTANTE */][/* UNA CONSTANTE */], char direccion, juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
void mover_snitch(char campo[/* UNA CONSTANTE */][/* UNA CONSTANTE */], juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
void mover_bludgers(char campo[/* UNA CONSTANTE */][/* UNA CONSTANTE */], juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
coordenada_t posicion_inicial_snitch();

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
bool finalizo_juego(juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
void mostrar_resultado(juego_t juego);

#endif /* QUIDDITCH_H */