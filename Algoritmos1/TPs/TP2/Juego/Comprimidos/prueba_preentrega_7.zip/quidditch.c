
#include "quidditch.h"


#define BLUDGER_1 0
#define BLUDGER_2 1
#define BLUDGER_3 2
#define BLUDGER_4 3
#define BLUDGER_5 4
#define DIMENSIONES 2
#define HUFFLEPUFF 'H'
#define GRYFFINDOR 'G'
#define SLYTHERIN 'S'
#define RAVENCLAW 'R'
#define ULTIMA_COLUMNA_CAMPO 14
#define PRIMERA_COLUMNA_CAMPO 0
#define ULTIMA_FILA_CAMPO 24
#define PRIMERA_FILA_CAMPO 0
#define CANTIDAD_DESPLAZAMIENTOS_POSIBLES_DE_SNITCH 4
#define NO_CHOCA_BLUDGERS -1



//ERRORES: _La snitch se posa sobre el jugador si este va a la esquina y esta era
//         antes la unica posicion disponible
//         _Las bludgers no se mueven hasta que el jugador haga el segundo movimiento









//tipo de dato usado para asociar la posicion
//valida a su distancia del jugador
typedef struct movimiento_valido {

  coordenada_t posicion;
  int distancia_del_jugador;

}movimiento_valido_t;


void eliminar_elemento(coordenada_t obstaculos[], int posicion_elemento, int* tope){

  for (int i = posicion_elemento; i < (*tope)-1; i++) {

    /*obstaculos[i].fila=obstaculos[i+1].fila;
    obstaculos[i].columna=obstaculos[i+1].columna;*/

    obstaculos[i]=obstaculos[i+1];
  }
  *tope-=1;
}

int bludger_que_choca_jugador(juego_t juego){

  bool hay_choque=false;
  int bludger_chocada=0;

  for (int i = 0; i < juego.bludgers_en_juego; i++) {

    if ((juego.casa!=SLYTHERIN)&&(juego.posicion_jugador.fila==juego.posicion_bludgers[i].fila)&&(juego.posicion_jugador.columna==juego.posicion_bludgers[i].columna)) {

      hay_choque=true;
      bludger_chocada=i;
    }
  }

  if (!hay_choque){

    return NO_CHOCA_BLUDGERS;
  }

  return bludger_chocada;
}


//precondición: las posiciones deben pertenecer a movimientos válidos
// ya que si no lo son puede devolver una posición no permitida
//postcondición: la posicioón que priorizará la snitch de las dos enviadas
coordenada_t determinar_posicion_prioritaria(coordenada_t posicion1, coordenada_t posicion2){

  coordenada_t posicion_prioritaria;

  if (posicion1.columna==posicion2.columna) {

    if (posicion1.fila<posicion2.fila) {

      posicion_prioritaria=posicion1;
    }else{

      posicion_prioritaria=posicion2;
    }
  }
  if (posicion1.fila==posicion2.fila) {

    if (posicion1.columna<posicion2.columna) {

      posicion_prioritaria=posicion1;
    }else{

      posicion_prioritaria=posicion2;
    }
  }

  return posicion_prioritaria;
}


bool esta_en_submatriz_ravenclaw(coordenada_t posicion_objeto, juego_t juego){

  bool esta_en_submatriz=false;
  int i=0;
  int j=0;
  int minima_fila_dentro_del_campo_submatriz=juego.posicion_jugador.fila-1;
  int minima_columna_dentro_del_campo_submatriz=juego.posicion_jugador.columna-1;
  int maxima_fila_dentro_del_campo_submatriz=juego.posicion_jugador.fila+1;
  int maxima_columna_dentro_del_campo_submatriz=juego.posicion_jugador.columna+1;

  //se ve si las posiciones de la submatriz están dentro del campo,
  //si no lo están entonces se recorta la submatriz de manera que lo esté
  if (minima_fila_dentro_del_campo_submatriz<PRIMERA_FILA_CAMPO) {
    minima_fila_dentro_del_campo_submatriz=PRIMERA_FILA_CAMPO;
  }

  if (minima_columna_dentro_del_campo_submatriz<PRIMERA_COLUMNA_CAMPO) {
    minima_columna_dentro_del_campo_submatriz=PRIMERA_COLUMNA_CAMPO;
  }


  if (maxima_fila_dentro_del_campo_submatriz>ULTIMA_FILA_CAMPO) {

    maxima_fila_dentro_del_campo_submatriz=ULTIMA_FILA_CAMPO;
  }

  if (maxima_columna_dentro_del_campo_submatriz>ULTIMA_COLUMNA_CAMPO) {

    maxima_columna_dentro_del_campo_submatriz=ULTIMA_COLUMNA_CAMPO;
  }

  i=minima_fila_dentro_del_campo_submatriz;
  j=minima_columna_dentro_del_campo_submatriz;

  //se ve si la posicion está dentro de la submatriz
  while (i<=maxima_fila_dentro_del_campo_submatriz) {

    while (j<=maxima_columna_dentro_del_campo_submatriz) {

      if((i==juego.posicion_jugador.fila)&&(j==juego.posicion_jugador.columna)){

        j++;
      }

      if ((posicion_objeto.fila=i)&&(posicion_objeto.columna=j)) {

        esta_en_submatriz=true;
      }
    }

    j=minima_columna_dentro_del_campo_submatriz;
    i++;
  }

  return esta_en_submatriz;
}


//precondición:recibe en posicion una de las posibles 4 nuevas posiciones posibles de la snitch
//postcondición: devuelve un booleano que indica si esa posicion cumple con las condiciones
//necesarias para que la snitch pueda desplazarse allí
bool es_posicion_valida(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], coordenada_t posicion, juego_t juego){

  bool es_valida=true;

  if (campo[posicion.fila][posicion.columna]!=' ') {

    es_valida=false;

  }

  if ((posicion.fila>ULTIMA_FILA_CAMPO)||(posicion.fila<PRIMERA_FILA_CAMPO)||(posicion.columna>ULTIMA_COLUMNA_CAMPO)||(posicion.columna<PRIMERA_COLUMNA_CAMPO)) {

    es_valida=false;

  }

  if ((posicion.fila==juego.posicion_jugador.fila)&&(posicion.columna==juego.posicion_jugador.columna)) {

    es_valida=false;
  }

  if (juego.casa==RAVENCLAW) {

    if (esta_en_submatriz_ravenclaw(posicion, juego)) {
      es_valida=false;
    }
  }

  return es_valida;
}



//precondicion: el movimiento otorgado debe ser un movimiento válido
//y el jugador debe estar dentro del campo de juego
//postcondicion: devuelve si el jugador está o no dentro del campo
//haciendo ese movimiento
bool esta_dentro_del_campo(char movimiento, coordenada_t posicion_jugador){

  bool esta_dentro=true;

  if ((posicion_jugador.fila==ULTIMA_FILA_CAMPO)&&(movimiento==ABAJO)) {

      esta_dentro=false;
  }

  if ((posicion_jugador.fila==PRIMERA_FILA_CAMPO)&&(movimiento==ARRIBA)) {

      esta_dentro=false;
  }

  if ((posicion_jugador.columna==PRIMERA_COLUMNA_CAMPO)&&(movimiento==IZQUIERDA)) {

      esta_dentro=false;
  }

  if ((posicion_jugador.columna==ULTIMA_COLUMNA_CAMPO)&&(movimiento==DERECHA)) {

      esta_dentro=false;
  }


  return esta_dentro;
}

//preciondiciones: -
//postcondicion: devuelbe un booleano que indica si es
//una tecla valida(verdadero cuando no está habilitada y
//falso cuando está habilitada)
bool es_tecla_habilitada(char movimiento){

  bool esta_habilitada=true;


  if ((movimiento!=ARRIBA)&&(movimiento!=ABAJO)&&(movimiento!=IZQUIERDA)&&(movimiento!=DERECHA)) {

    esta_habilitada=false;

  }

  return esta_habilitada;

}

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE calcular_distancia_manhattan
 */

//precondicion: los valores que recibe deben ser positivos
//postcondicion: - (¿no hay porque el nombre es claro?)

int calcular_distancia_manhattan(coordenada_t posicion1, coordenada_t posicion2){

//cambiar parametros formales a coordenada_t

  int distancia_filas=posicion2.fila-posicion1.fila;
  int distancia_columnas=posicion2.columna-posicion1.columna;
  int distancia_total=0;

  //se aplica el modulo a las distancias para que sean siempre positivas
  if (distancia_filas<0) {

    distancia_filas=-distancia_filas;

  }

  if (distancia_columnas<0) {

    distancia_columnas=-distancia_columnas;

  }

  distancia_total=distancia_filas+distancia_columnas;

  return distancia_total;

}





void dejar_espacio(){

  for (int i = 0; i < 100; i++) {

    printf("\n");

  }

}




void actualizar_matriz(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t juego){

//¿BORRA Y REESCRIBE TODA LA MATRIZ?¿O ACTUALIZAR LA MATRIZ PARA CADA CASO
//CUANDO SEA NECESARIO SOLO EN LA PARTE QUE HAYA QUE CAMBIAR?

//¿¿¿¿CAMBIAR??????????????
for (int i = 0; i < CANTIDAD_FILAS; i++) {

  for (int j = 0; j < CANTIDAD_COLUMNAS; j++) {

    campo[i][j]=' ';
  }
}


campo[juego.posicion_jugador.fila][juego.posicion_jugador.columna]= JUGADOR;


//pasar a funcion establecer posicion bludgers(¿hacer funcion general
//de establecerposicion?)
for (int l = 0; l < juego.bludgers_en_juego; l++) {
  campo[juego.posicion_bludgers[l].fila][juego.posicion_bludgers[l].columna]=BLUDGER;
}


//pasar a establecer posicion dementores (¿necesario?)
for (int m = 0; m < juego.dementores_en_juego; m++) {
  campo[juego.posicion_dementores[m].fila][juego.posicion_dementores[m].columna]= DEMENTOR;
}


campo[juego.posicion_snitch.fila][juego.posicion_snitch.columna]= SNITCH;

}


void imprimir_matriz(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS]){

  for (int i = 0; i < CANTIDAD_COLUMNAS+2; i++) {

    printf("*");
  }
  printf("\n");

  for (int i = 0; i < CANTIDAD_FILAS; i++) {

    printf("*");
    for (int j = 0; j < CANTIDAD_COLUMNAS; j++) {

      printf("%c", campo[i][j]);
    }
    printf("*\n");
  }

  for (int i = 0; i < CANTIDAD_COLUMNAS+2; i++) {

    printf("*");
  }

  printf("\n");
}


void inicializar_juego(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], char casa, juego_t *juego){

  //campo[CENTRO_FILAS][CENTRO_COLUMNAS]= JUGADOR;
  int filas_iniciales_bludgers[CANTIDAD_INICIAL_BLUDGERS]={FILA_BLUDGER_1, FILA_BLUDGER_2, FILA_BLUDGER_3, FILA_BLUDGER_4, FILA_BLUDGER_5};
  int posiciones_dementores[DIMENSIONES][CANTIDAD_INICIAL_DEMENTORES]= {
  {FILA_DEMENTOR_1, FILA_DEMENTOR_2, FILA_DEMENTOR_3, FILA_DEMENTOR_4},
  {COLUMNA_DEMENTOR_1, COLUMNA_DEMENTOR_2, COLUMNA_DEMENTOR_3, COLUMNA_DEMENTOR_4}};

  (*juego).posicion_jugador.fila= CENTRO_FILAS;
  (*juego).posicion_jugador.columna= CENTRO_COLUMNAS;
  (*juego).resistencia= RESISTENCIA_INICIAL;
  (*juego).casa= casa;

  (*juego).bludgers_en_juego=  CANTIDAD_INICIAL_BLUDGERS;
  (*juego).direccion= HACIA_DERECHA;
  for (int i = 0; i < CANTIDAD_INICIAL_BLUDGERS; i++) {
    (*juego).posicion_bludgers[i].fila=filas_iniciales_bludgers[i];
    (*juego).posicion_bludgers[i].columna= COLUMNA_INICIAL_BLUDGERS;
  }

  //pasar a vector de coordenada_t
  (*juego).dementores_en_juego= CANTIDAD_INICIAL_DEMENTORES;
  for (int j = 0; j < CANTIDAD_INICIAL_DEMENTORES; j++) {
    (*juego).posicion_dementores[j].fila=posiciones_dementores[0][j];
  }
  for (int k = 0; k < CANTIDAD_INICIAL_DEMENTORES; k++) {
    (*juego).posicion_dementores[k].columna=posiciones_dementores[1][k];
  }

  (*juego).estado=EN_EJECUCION;


  //pasar a la funcion actualizar matriz
  campo[(*juego).posicion_jugador.fila][(*juego).posicion_jugador.columna]= JUGADOR;


  //pasar a funcion establecer posicion bludgers(¿hacer funcion general
  //de establecerposicion?)
  for (int l = 0; l < CANTIDAD_INICIAL_BLUDGERS; l++) {
    campo[(*juego).posicion_bludgers[l].fila][(*juego).posicion_bludgers[l].columna]=BLUDGER;
  }


  //pasar a establecer posicion dementores (¿necesario?)
  for (int m = 0; m < CANTIDAD_INICIAL_DEMENTORES; m++) {
    campo[(*juego).posicion_dementores[m].fila][(*juego).posicion_dementores[m].columna]= DEMENTOR;
  }

  (*juego).posicion_snitch=posicion_inicial_snitch();

}

char pedir_movimiento(coordenada_t posicion_jugador){

//¿Las interacciones con el usuario no eran con void?
  char movimiento;

  do {


    /*if (strlen(movimiento)>1) {
      //arreglar doble impresion de esto
      //arreglar avance de mas de un espacio escribiendo mas de un caracter
    printf("Escribir una sola letra por favor");

  }*/

    //agregar if fuera de matriz

    printf("Inserte movimiento:");
    scanf(" %c", &movimiento);

    if (!(es_tecla_habilitada(movimiento))) {
      //arreglar doble impresion de esto
      //arreglar avance de mas de un espacio escribiendo mas de un caracter
      printf("Tecla incorrecta, por favor ingrese 'w', 'a','s' o 'd'.");
    }


    if (!(esta_dentro_del_campo(movimiento, posicion_jugador))) {

      printf("El movimiento lo deja fuera del campo de juego, por favor ingrese otra direccion");
    }

  } while(!(es_tecla_habilitada(movimiento))||(!(esta_dentro_del_campo(movimiento, posicion_jugador)))/*&&(strlen(movimiento)>1)*//*&&(agregar validacion para ver si el movimiento lo deja afuera de la matriz)*/);


  return movimiento;

}

void mover_jugador(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], char direccion, juego_t *juego){

  //PARA CORRECTOR: el siguiente codigo es para incluir
  //el caso de hufflepuff ¿estaría bien que quede acá?
  //¿O debería ponerlo en el main de juego.c?

  /*int cantidad_movimientos_por_turno=1;
  int i=0;

  if ((*juego).casa=HUFFLEPUFF) {
  cantidad_movimientos_por_turno=2;
  }

  while (i<cantidad_movimientos_por_turno) {

  }
  */

  int bludger_chocada=0;

  switch (direccion) {
    case ARRIBA:
    (*juego).posicion_jugador.fila--;
    break;

    case ABAJO:
    (*juego).posicion_jugador.fila++;
    break;

    case IZQUIERDA:
    (*juego).posicion_jugador.columna--;
    break;

    case DERECHA:
    (*juego).posicion_jugador.columna++;
    break;
  }

  if (bludger_que_choca_jugador(*juego)!=NO_CHOCA_BLUDGERS) {

    bludger_chocada=bludger_que_choca_jugador(*juego);
    (*juego).resistencia-=10;
    eliminar_elemento((*juego).posicion_bludgers, bludger_chocada, &((*juego).bludgers_en_juego));

    }
    //agregar resta de resistencia

    //PARA CORRECTOR:dejar estas 3 llamadas a funciones en main?

    //PARA CORRECTOR:una cosa que no termina de quedarme clara es
    //dónde tenemos que ver si el jugador intercepta una bludger o
    //la snitch, porque según las buenas prácticas de programación
    //las funciones deberían hacer una sola cosa, pero las pruenas de
    //la preentrega ven si el jugador cae en la snitch, si el jugador
    //intercepta una bludger y si el jugador cae en la misma posición
    //que un dementor, y se supone que la preentrega es solo de
    //mover_snitch, mover_jugador y mover_bludgers

    actualizar_matriz(campo, *juego);
    //dejar_espacio();
    //imprimir_matriz(campo);
  }



void mover_snitch(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t *juego){

  //se agregan estas variables para que no queden argumenos locales
  //demasiado largos
  coordenada_t posicion_definitiva;
  movimiento_valido_t movimiento_mas_distante;
  movimiento_valido_t segundo_movimiento_mas_distante;

  coordenada_t coordenadas_snitch= (*juego).posicion_snitch;
  coordenada_t coordenadas_jugador= (*juego).posicion_jugador;
  coordenada_t coordenadas_arriba_izquierda_snitch= {(*juego).posicion_snitch.fila-1,(*juego).posicion_snitch.columna-1};
  coordenada_t coordenadas_arriba_derecha_snitch= {(*juego).posicion_snitch.fila-1,(*juego).posicion_snitch.columna+1};
  coordenada_t coordenadas_abajo_izquierda_snitch= {(*juego).posicion_snitch.fila+1,(*juego).posicion_snitch.columna-1};
  coordenada_t coordenadas_abajo_derecha_snitch={(*juego).posicion_snitch.fila+1,(*juego).posicion_snitch.columna+1};


  //se crean dos vectores: uno para almacenar las posiciones a las que se podría desplazar la
  //snitch, sin tomar en cuenta las distancias de estas al jugador; otro para guardar las
  //distancias de esas posiciones
  movimiento_valido_t movimientos_validos_snitch[CANTIDAD_DESPLAZAMIENTOS_POSIBLES_DE_SNITCH];
  int tope_movimientos_validos=0;

  int distancia_jugador_a_snitch=calcular_distancia_manhattan(coordenadas_jugador, coordenadas_snitch);


  if (distancia_jugador_a_snitch<=DISTANCIA_MAXIMA_JUGADOR_A_SNITCH_CON_MOVIMIENTO) {

    //establece la prioridad de movimiento de la snitch como si
    //todas las distancias de las posiciones al jugador fueran las mismas

    if (es_posicion_valida(campo, coordenadas_arriba_izquierda_snitch, (*juego))) {

      movimientos_validos_snitch[tope_movimientos_validos].posicion=coordenadas_arriba_izquierda_snitch;
      movimientos_validos_snitch[tope_movimientos_validos].distancia_del_jugador=calcular_distancia_manhattan(coordenadas_jugador, coordenadas_arriba_izquierda_snitch);
      tope_movimientos_validos++;
    }

    if (es_posicion_valida(campo, coordenadas_arriba_derecha_snitch, (*juego))) {

      movimientos_validos_snitch[tope_movimientos_validos].posicion=coordenadas_arriba_derecha_snitch;
      movimientos_validos_snitch[tope_movimientos_validos].distancia_del_jugador=calcular_distancia_manhattan(coordenadas_jugador, coordenadas_arriba_derecha_snitch);
      tope_movimientos_validos++;
    }

    if (es_posicion_valida(campo, coordenadas_abajo_izquierda_snitch, (*juego))) {

      movimientos_validos_snitch[tope_movimientos_validos].posicion=coordenadas_abajo_izquierda_snitch;
      movimientos_validos_snitch[tope_movimientos_validos].distancia_del_jugador=calcular_distancia_manhattan(coordenadas_jugador, coordenadas_abajo_izquierda_snitch);
      tope_movimientos_validos++;
    }

    if (es_posicion_valida(campo, coordenadas_abajo_derecha_snitch, (*juego))) {

      movimientos_validos_snitch[tope_movimientos_validos].posicion=coordenadas_abajo_derecha_snitch;
      movimientos_validos_snitch[tope_movimientos_validos].distancia_del_jugador=calcular_distancia_manhattan(coordenadas_jugador, coordenadas_abajo_derecha_snitch);
      tope_movimientos_validos++;
    }

    //se buscan las posiciones asociadas a los dos lugares mas distantes
    //en los que se podrá ubicar la snitch, asumiendo que el primer elemento
    //es el mayor y el segundo elemento el segundo mayor, luego se corrobora

    if (tope_movimientos_validos>0) {

      movimiento_mas_distante=movimientos_validos_snitch[0];

      if (tope_movimientos_validos==1) {

        posicion_definitiva=movimiento_mas_distante.posicion;//cambiar si no se quiere q se mueva en la esquina
      }

      if (tope_movimientos_validos>1) {

        segundo_movimiento_mas_distante=movimientos_validos_snitch[1];
      }

      for (int i = 1; i < tope_movimientos_validos; i++) {

        if (movimientos_validos_snitch[i].distancia_del_jugador>movimiento_mas_distante.distancia_del_jugador) {

            segundo_movimiento_mas_distante=movimiento_mas_distante;
            movimiento_mas_distante=movimientos_validos_snitch[i];
        }else if(movimientos_validos_snitch[i].distancia_del_jugador>segundo_movimiento_mas_distante.distancia_del_jugador){

          segundo_movimiento_mas_distante=movimientos_validos_snitch[i];
        }
      }

      if ((movimiento_mas_distante.distancia_del_jugador!=segundo_movimiento_mas_distante.distancia_del_jugador)) {

          posicion_definitiva=movimiento_mas_distante.posicion;
      }

      if (movimiento_mas_distante.distancia_del_jugador==segundo_movimiento_mas_distante.distancia_del_jugador) {

        posicion_definitiva= determinar_posicion_prioritaria(movimiento_mas_distante.posicion, segundo_movimiento_mas_distante.posicion);
      }


      (*juego).posicion_snitch=posicion_definitiva;
    }
  }


//PARA CORRECTOR: para ver si los movimientos son validos se usará la función
//es_posicion_valida . EL código está comentado porque como todavía no están usadas
//las variables definidas tira error si se intentan compilar junto con el resto del código
}

void mover_bludgers(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t *juego){


  int bludger_chocada=0;

  int adicion_posicion_bludger=1;

  if ((*juego).direccion==HACIA_IZQUIERDA) {

    adicion_posicion_bludger=-1;
  }

  if ((*juego).direccion==HACIA_DERECHA) {

    adicion_posicion_bludger=1;
  }


  for (int i = 0; i < (*juego).bludgers_en_juego; i++) {

    (*juego).posicion_bludgers[i].columna+=adicion_posicion_bludger;
  }


  if ((*juego).bludgers_en_juego>0) {

    if ((*juego).posicion_bludgers[BLUDGER_1].columna==ULTIMA_COLUMNA_CAMPO) {

      (*juego).direccion=HACIA_IZQUIERDA;

    }

    if ((*juego).posicion_bludgers[BLUDGER_1].columna==PRIMERA_COLUMNA_CAMPO) {

      (*juego).direccion=HACIA_DERECHA;
    }

  }

  if (bludger_que_choca_jugador(*juego)!=NO_CHOCA_BLUDGERS) {

    bludger_chocada=bludger_que_choca_jugador(*juego);
    (*juego).resistencia-=10;
    eliminar_elemento((*juego).posicion_bludgers, bludger_chocada, &((*juego).bludgers_en_juego));
    }

  actualizar_matriz(campo, *juego);
}

coordenada_t posicion_inicial_snitch(){

  //SACAR EL RETURN USADO PARA QUE COMPILE
  coordenada_t centro_del_campo={CENTRO_FILAS, CENTRO_COLUMNAS};
  coordenada_t posicion_inicial;

  srand((unsigned int)clock());

  do {

    posicion_inicial.fila=rand()%ULTIMA_FILA_CAMPO;
    posicion_inicial.columna=rand()%ULTIMA_COLUMNA_CAMPO;

  } while(calcular_distancia_manhattan(posicion_inicial, centro_del_campo)<5);

  return posicion_inicial;
}

bool finalizo_juego(juego_t *juego){

//SACAR EL RETURN USADO PARA QUE COMPILE

  return false;
}

void mostrar_resultado(juego_t juego){


}
