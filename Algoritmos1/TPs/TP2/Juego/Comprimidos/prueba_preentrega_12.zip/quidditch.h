#ifndef QUIDDITCH_H
#define QUIDDITCH_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdbool.h>

#define CANTIDAD_INICIAL_BLUDGERS 5
#define CANTIDAD_INICIAL_DEMENTORES 4
#define CANTIDAD_FILAS 25
#define CANTIDAD_COLUMNAS 15
#define CENTRO_FILAS 12
#define CENTRO_COLUMNAS 7
#define JUGADOR 'J'
#define DEMENTOR 'D'
#define SNITCH 'S'
#define BLUDGER 'B'
#define RESISTENCIA_INICIAL 50
#define COLUMNA_INICIAL_BLUDGERS 0
#define FILA_1_DEMENTORES 5
#define FILA_2_DEMENTORES 19
#define COLUMNA_1_DEMENTORES 3
#define COLUMNA_2_DEMENTORES 11
#define EN_EJECUCION 0
#define JUGADOR_GANO 1
#define JUGADOR_PERDIO 2
#define ARRIBA 'w'
#define ABAJO 's'
#define IZQUIERDA 'a'
#define DERECHA 'd'
#define DISTANCIA_MAXIMA_JUGADOR_A_SNITCH_CON_MOVIMIENTO 10
#define HACIA_DERECHA 'D'
#define HACIA_IZQUIERDA 'I'
#define HUFFLEPUFF 'H'
#define GRYFFINDOR 'G'
#define SLYTHERIN 'S'
#define RAVENCLAW 'R'
#define PRIMER_MOVIMIENTO 1

/* ACA VAN LAS CONSTANTES */

typedef struct coordenada {
	int fila;
	int columna;
} coordenada_t;

typedef struct juego {
	coordenada_t posicion_jugador;
	char casa;
	int resistencia;
	coordenada_t posicion_snitch;

	int bludgers_en_juego; // tope del vector posicion_bludgers
	coordenada_t posicion_bludgers[CANTIDAD_INICIAL_BLUDGERS];
	char direccion; // 'D': derecha – 'I': izquierda

	int dementores_en_juego; // tope del vector posicion_dementores
	coordenada_t posicion_dementores[CANTIDAD_INICIAL_DEMENTORES];

	int estado; // 0: en ejecucion – 1: jugador gano – 2: jugador perdio
} juego_t;





//------FUNCIONES PROPIAS-----


//preciondiciones: la posicion del jugador debe estar dentro del campo de juego,
//en adición a esto, la función solo resultará util para el caso en el que el
//jugador pertenezca a ravenclaw (no funcionará erróneamente pero no será de utilidad)
//postcondicion: devuelve un booleano que indica si la posicion mandada
//esta dentro de las posiciones adyacentes al jugador
bool esta_en_submatriz_ravenclaw(coordenada_t posicion, juego_t juego);


/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE calcular_distancia_manhattan
 */
bool no_es_tecla_habilitada(char movimiento);



/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE dejar_espacio
 */
void dejar_espacio();



/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE actualizar_matriz
 */
void actualizar_matriz(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t juego);


/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE imprimir_matriz
 */
void imprimir_matriz(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS]);



//------FUNCIONES DADAS------

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE inicializar_juego
 */
void inicializar_juego(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], char casa, juego_t *juego);

//precondición: el jugador debe estar dentro del campo de juego (sino
//tomará como validos movimientos fuera de este)
//postcondición: devuelve un caracter que representa un movimiento válido
//dentro del campo de juego
char pedir_movimiento(coordenada_t posicion_jugador);

//precondición:la función debe recibir como parámetro una dirección de movimiento válida
//postcondición: devuelve como parámetro la nueva posición del jugador
//una vez hecho el movimiento
void mover_jugador(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], char direccion, juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
void mover_snitch(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
void mover_bludgers(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
coordenada_t posicion_inicial_snitch();

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
bool finalizo_juego(juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
void mostrar_resultado(juego_t juego);

#endif /* QUIDDITCH_H */
