#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "quidditch.h"


#define BLUDGER_1 0
#define BLUDGER_2 1
#define BLUDGER_3 2
#define BLUDGER_4 3
#define BLUDGER_5 4
#define DIMENSIONES 2
#define HUFFLEPUFF 'H'
#define GRYFFINDOR 'G'
#define SLYTHERIN 'S'
#define RAVENCLAW 'R'




bool no_es_tecla_habilitada(char movimiento){

  bool no_esta_habilitada=false;


  if ((movimiento!=ADELANTE)&&(movimiento!=ATRAS)&&(movimiento!=IZQUIERDA)&&(movimiento!=DERECHA)) {

    no_esta_habilitada=true;

  }

  return no_esta_habilitada;

}



int calcular_distancia_manhattan(int fila1, int columna1, int fila2, int columna2){

  int distancia_filas=fila2-fila1;
  int distancia_columnas=columna2-columna1;
  int distancia_total=0;


  if (distancia_filas<0) {

    distancia_filas=-distancia_filas;

  }

  if (distancia_columnas<0) {

    distancia_columnas=-distancia_columnas;

  }

  distancia_total=distancia_filas+distancia_columnas;

  return distancia_total;

}





void dejar_espacio(){

  for (int i = 0; i < 100; i++) {

    printf("\n");

  }

}




void actualizar_matriz(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t juego){

//¿BORRA Y REESCRIBE TODA LA MATRIZ?¿O ACTUALIZAR LA MATRIZ PARA CADA CASO
//CUANDO SEA NECESARIO SOLO EN LA PARTE QUE HAYA QUE CAMBIAR?

//¿¿¿¿CAMBIAR??????????????
for (int i = 0; i < CANTIDAD_FILAS; i++) {

  for (int j = 0; j < CANTIDAD_COLUMNAS; j++) {

    campo[i][j]=' ';
  }
}


campo[juego.posicion_jugador.fila][juego.posicion_jugador.columna]= JUGADOR;


//pasar a funcion establecer posicion bludgers(¿hacer funcion general
//de establecerposicion?)
for (int l = 0; l < juego.bludgers_en_juego; l++) {
  campo[juego.posicion_bludgers[l].fila][juego.posicion_bludgers[l].columna]=BLUDGER;
}


//pasar a establecer posicion dementores (¿necesario?)
for (int m = 0; m < juego.dementores_en_juego; m++) {
  campo[juego.posicion_dementores[m].fila][juego.posicion_dementores[m].columna]= DEMENTOR;
}


campo[juego.posicion_snitch.fila][juego.posicion_snitch.columna]= SNITCH;

}


void imprimir_matriz(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS]){

  for (int i = 0; i < CANTIDAD_FILAS; i++) {

    for (int j = 0; j < CANTIDAD_COLUMNAS; j++) {

      printf("%c", campo[i][j]);
    }
    printf("\n");
  }


}


void inicializar_juego(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], char casa, juego_t *juego){

  //campo[CENTRO_FILAS][CENTRO_COLUMNAS]= JUGADOR;
  int filas_iniciales_bludgers[CANTIDAD_INICIAL_BLUDGERS]={FILA_BLUDGER_1, FILA_BLUDGER_2, FILA_BLUDGER_3, FILA_BLUDGER_4, FILA_BLUDGER_5};
  int posiciones_dementores[DIMENSIONES][CANTIDAD_INICIAL_DEMENTORES]= {
  {FILA_DEMENTOR_1, FILA_DEMENTOR_2, FILA_DEMENTOR_3, FILA_DEMENTOR_4},
  {COLUMNA_DEMENTOR_1, COLUMNA_DEMENTOR_2, COLUMNA_DEMENTOR_3, COLUMNA_DEMENTOR_4}};

  (*juego).posicion_jugador.fila= CENTRO_FILAS;
  (*juego).posicion_jugador.columna= CENTRO_COLUMNAS;
  (*juego).resistencia= RESISTENCIA_INICIAL;
  (*juego).casa= casa;

  (*juego).bludgers_en_juego=  CANTIDAD_INICIAL_BLUDGERS;
  (*juego).direccion= 'D';
  for (int i = 0; i < CANTIDAD_INICIAL_BLUDGERS; i++) {
    (*juego).posicion_bludgers[i].fila=filas_iniciales_bludgers[i];
    (*juego).posicion_bludgers[i].columna= COLUMNA_INICIAL_BLUDGERS;
  }

  //cambiar "numero magicos"
  (*juego).dementores_en_juego= CANTIDAD_INICIAL_DEMENTORES;
  for (int j = 0; j < CANTIDAD_INICIAL_DEMENTORES; j++) {
    (*juego).posicion_dementores[j].fila=posiciones_dementores[0][j];
  }
  for (int k = 0; k < CANTIDAD_INICIAL_DEMENTORES; k++) {
    (*juego).posicion_dementores[k].columna=posiciones_dementores[1][k];
  }

  (*juego).estado=EN_EJECUCION;


  //HACER BIEN POSICION SNITCH
  (*juego).posicion_snitch.fila=2;
  (*juego).posicion_snitch.columna=2;

  //pasar a la funcion actualizar matriz
  campo[(*juego).posicion_jugador.fila][(*juego).posicion_jugador.columna]= JUGADOR;


  //pasar a funcion establecer posicion bludgers(¿hacer funcion general
  //de establecerposicion?)
  for (int l = 0; l < CANTIDAD_INICIAL_BLUDGERS; l++) {
    campo[(*juego).posicion_bludgers[l].fila][(*juego).posicion_bludgers[l].columna]=BLUDGER;
  }


  //pasar a establecer posicion dementores (¿necesario?)
  for (int m = 0; m < CANTIDAD_INICIAL_DEMENTORES; m++) {
    campo[(*juego).posicion_dementores[m].fila][(*juego).posicion_dementores[m].columna]= DEMENTOR;
  }

}

char pedir_movimiento(coordenada_t posicion_jugador){

//¿Las interacciones con el usuario no eran con void?
  char movimiento='w';

//SACAR EL RETURN USADO PARA QUE COMPILE
  do {

    if (no_es_tecla_habilitada(movimiento)) {
      //arreglar doble impresion de esto
      //arreglar avance de mas de un espacio escribiendo mas de un caracter
    printf("Tecla incorrecta, por favor ingrese 'w', 'a','s' o 'd'");

    }

    /*if (strlen(movimiento)>1) {
      //arreglar doble impresion de esto
      //arreglar avance de mas de un espacio escribiendo mas de un caracter
    printf("Escribir una sola letra por favor");

  }*/

    //agregar if fuera de matriz

    printf("Inserte movimiento:");
    scanf("%c", &movimiento);

  } while((no_es_tecla_habilitada(movimiento))/*&&(strlen(movimiento)>1)*//*&&(agregar validacion para ver si el movimiento lo deja afuera de la matriz)*/);


  return movimiento;

}

void mover_jugador(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], char direccion, juego_t *juego){

  //PARA CORRECTOR: el siguiente codigo es para incluir
  //el caso de hufflepuff ¿estaría bien que quede acá?
  //¿O debería ponerlo en el main de juego.c?

  /*int cantidad_movimientos_por_turno=1;
  int i=0;

  if ((*juego).casa=HUFFLEPUFF) {
  cantidad_movimientos_por_turno=2;
  }

  while (i<cantidad_movimientos_por_turno) {

  }
  */

  //¿INVERTIR LLAMADA ENTRE mover_jugador Y pedir_movimiento?

  switch (direccion) {
    case ADELANTE:
    (*juego).posicion_jugador.fila--;
    break;

    case ATRAS:
    (*juego).posicion_jugador.fila++;
    break;

    case IZQUIERDA:
    (*juego).posicion_jugador.columna--;
    break;

    case DERECHA:
    (*juego).posicion_jugador.columna++;
    break;
  }



  //PARA CORRECTOR:mover a main?
  actualizar_matriz(campo,*juego);
  dejar_espacio();
  imprimir_matriz(campo);


}

void mover_snitch(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t *juego){

  //se agregan estas variables para que no queden argumenos locales
  //demasiado largos

  /*coordenada_t coordenadas_snitch= (*juego).posicion_snitch;
  coordenada_t coordenadas_jugador= (*juego).posicion_jugador;
  coordenada_t coordenadas_arriba_izquierda_snitch= {(*juego).posicion_snitch.fila-1,(*juego).posicion_snitch.columna-1};
  coordenada_t coordenadas_arriba_derecha_snitch= {(*juego).posicion_snitch.fila-1,(*juego).posicion_snitch.columna+1};
  coordenada_t coordenadas_abajo_izquierda_snitch= {(*juego).posicion_snitch.fila+1,(*juego).posicion_snitch.columna-1};
  coordenada_t coordenadas_abajo_derecha_snitch={(*juego).posicion_snitch.fila+1,(*juego).posicion_snitch.columna+1};

  int distancia_jugador_a_snitch=calcular_distancia_manhattan(coordenadas_jugador.fila, coordenadas_jugador.columna, coordenadas_snitch.fila, coordenadas_snitch.columna);
  int distancia_arriba_izquierda_snitch_a_jugador=calcular_distancia_manhattan(coordenadas_jugador.fila, coordenadas_jugador.columna, coordenadas_arriba_izquierda_snitch.fila, coordenadas_arriba_izquierda_snitch.columna);
  int distancia_arriba_derecha_snitch_a_jugador=calcular_distancia_manhattan(coordenadas_jugador.fila, coordenadas_jugador.columna, coordenadas_arriba_derecha_snitch.fila, coordenadas_arriba_derecha_snitch.columna);
  int distancia_abajo_izquierda_snitch_a_jugador=calcular_distancia_manhattan(coordenadas_jugador.fila, coordenadas_jugador.columna, coordenadas_abajo_izquierda_snitch.fila, coordenadas_abajo_izquierda_snitch.columna);
  int distancia_abajo_derecha_snitch_a_jugador=calcular_distancia_manhattan(coordenadas_jugador.fila, coordenadas_jugador.columna, coordenadas_abajo_derecha_snitch.fila, coordenadas_abajo_derecha_snitch.columna);


  if (distancia_jugador_snitch<=DISTANCIA_MAXIMA_JUGADOR_SNITCH_CON_MOVIMIENTO) {

//agregar chequeo para ver si un lugar ya está ocupado

}*/

}

void mover_bludgers(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t *juego){

  int adicion_posicion_bludger=1;

  if ((*juego).direccion=='I') {

    adicion_posicion_bludger=-1;
  }

  for (int i = 0; i < (*juego).bludgers_en_juego; i++) {

    (*juego).posicion_bludgers[i].columna+=adicion_posicion_bludger;
  }


  //agregar condiciones para q cambie a izquierda o derecha
  //if (/* condition */) {
    /* code */
  //}

}

coordenada_t posicion_inicial_snitch(){

  //SACAR EL RETURN USADO PARA QUE COMPILE

  coordenada_t demn={1,2};
  return demn;
}

bool finalizo_juego(juego_t *juego){

//SACAR EL RETURN USADO PARA QUE COMPILE

  return false;

}

void mostrar_resultado(juego_t juego){


}
