#ifndef QUIDDITCH_H
#define QUIDDITCH_H

#define CANTIDAD_INICIAL_BLUDGERS 5
#define CANTIDAD_INICIAL_DEMENTORES 4
#define CANTIDAD_FILAS 25
#define CANTIDAD_COLUMNAS 15
#define CENTRO_FILAS 12
#define CENTRO_COLUMNAS 7
#define JUGADOR 'J'
#define DEMENTOR 'D'
#define SNITCH 'S'
#define BLUDGER 'B'
#define FILA_BLUDGER_1 2
#define FILA_BLUDGER_2 7
#define FILA_BLUDGER_3 12
#define FILA_BLUDGER_4 17
#define FILA_BLUDGER_5 22
#define RESISTENCIA_INICIAL 50
#define COLUMNA_INICIAL_BLUDGERS 0
#define FILA_DEMENTOR_1 5
#define FILA_DEMENTOR_2 5
#define FILA_DEMENTOR_3 19
#define FILA_DEMENTOR_4 19
#define COLUMNA_DEMENTOR_1 3
#define COLUMNA_DEMENTOR_2 11
#define COLUMNA_DEMENTOR_3 3
#define COLUMNA_DEMENTOR_4 11
#define EN_EJECUCION 0
#define JUGADOR_GANO 1
#define JUGADOR_PERDIO 1
#define ADELANTE 'w'
#define ATRAS 's'
#define IZQUIERDA 'a'
#define DERECHA 'd'
#define DISTANCIA_MAXIMA_JUGADOR_SNITCH_CON_MOVIMIENTO 10

/* ACA VAN LAS CONSTANTES */

typedef struct coordenada {
	int fila;
	int columna;
} coordenada_t;

typedef struct juego {
	coordenada_t posicion_jugador;
	char casa;
	int resistencia;
	coordenada_t posicion_snitch;

	int bludgers_en_juego; // tope del vector posicion_bludgers
	coordenada_t posicion_bludgers[CANTIDAD_INICIAL_BLUDGERS];
	char direccion; // 'D': derecha – 'I': izquierda

	int dementores_en_juego; // tope del vector posicion_dementores
	coordenada_t posicion_dementores[CANTIDAD_INICIAL_DEMENTORES];

	int estado; // 0: en ejecucion – 1: jugador gano – 2: jugador perdio
} juego_t;





//------FUNCIONES PROPIAS-----


/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE calcular_distancia_manhattan
 */
bool no_es_tecla_habilitada(char movimiento);


/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE calcular_distancia_manhattan
 */

int calcular_distancia_manhattan(int fila1, int columna1, int fila2, int columna2);


/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE dejar_espacio
 */
void dejar_espacio();



/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE actualizar_matriz
 */
void actualizar_matriz(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t juego);


/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE imprimir_matriz
 */
void imprimir_matriz(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS]);



//------FUNCIONES DADAS------

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE inicializar_juego
 */
void inicializar_juego(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], char casa, juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
char pedir_movimiento(coordenada_t posicion_jugador);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
void mover_jugador(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], char direccion, juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
void mover_snitch(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
void mover_bludgers(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
coordenada_t posicion_inicial_snitch();

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
bool finalizo_juego(juego_t *juego);

/*
 * ACA VAN LAS PRE Y POST CONDICIONES DE pedir_movimiento
 */
void mostrar_resultado(juego_t juego);

#endif /* QUIDDITCH_H */
