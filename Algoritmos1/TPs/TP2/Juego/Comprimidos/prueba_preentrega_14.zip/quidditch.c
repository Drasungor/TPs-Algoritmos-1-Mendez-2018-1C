
#include "quidditch.h"

#define BLUDGER_1 0
#define ULTIMA_COLUMNA_CAMPO 14
#define PRIMERA_COLUMNA_CAMPO 0
#define ULTIMA_FILA_CAMPO 24
#define PRIMERA_FILA_CAMPO 0
#define CANTIDAD_DESPLAZAMIENTOS_POSIBLES_DE_SNITCH 4
#define NO_HAY_CHOQUE -1
#define REDUCCION_RESISTENCIA_POR_CHOQUE 10
#define DISTANCIA_ENTRE_BLUDGERS 5


//tipo de dato usado para asociar la posicion
//valida a su distancia del jugador
typedef struct movimiento_valido {
  coordenada_t posicion;
  int distancia_del_jugador;

}movimiento_valido_t;

bool posiciones_son_iguales(coordenada_t coordenada1, coordenada_t coordenada2){

  bool coordenadas_son_iguales=false;

  if ((coordenada1.fila==coordenada2.fila)&&(coordenada1.columna==coordenada2.columna)) {

    coordenadas_son_iguales=true;
  }
  return coordenadas_son_iguales;
}


//devuelve cuánto avanza la bludger en cada turno (1 o -1)
//y cambia el estado de juego si es necesario
int determinar_sentido_bludgers(juego_t* juego) {

  int adicion_posicion_bludger;

  if ((*juego).bludgers_en_juego>0) {

    if ((*juego).posicion_bludgers[BLUDGER_1].columna==ULTIMA_COLUMNA_CAMPO) {
      (*juego).direccion=HACIA_IZQUIERDA;
    }

    if ((*juego).posicion_bludgers[BLUDGER_1].columna==PRIMERA_COLUMNA_CAMPO) {
      (*juego).direccion=HACIA_DERECHA;
    }
  }

  if ((*juego).direccion==HACIA_IZQUIERDA) {
    adicion_posicion_bludger=-1;
  }

  if ((*juego).direccion==HACIA_DERECHA) {
    adicion_posicion_bludger=1;
  }

  return adicion_posicion_bludger;
}


//precondición:recibe en posicion una de las posibles 4 nuevas posiciones posibles de la snitch
//postcondición: devuelve un booleano que indica si esa posicion cumple con las condiciones
//necesarias para que la snitch pueda desplazarse allí
bool es_posicion_valida(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], coordenada_t posicion, juego_t juego){

  bool es_valida=true;

  if (campo[posicion.fila][posicion.columna]!=' ') {
    es_valida=false;
  }

  if ((posicion.fila>ULTIMA_FILA_CAMPO)||(posicion.fila<PRIMERA_FILA_CAMPO)||(posicion.columna>ULTIMA_COLUMNA_CAMPO)||(posicion.columna<PRIMERA_COLUMNA_CAMPO)) {
    es_valida=false;
  }

  //(posicion.fila==juego.posicion_jugador.fila)&&(posicion.columna==juego.posicion_jugador.columna)

  if (posiciones_son_iguales(posicion, juego.posicion_jugador)) {
    es_valida=false;
  }

  if (juego.casa==RAVENCLAW) {
    if (esta_en_submatriz_ravenclaw(posicion, juego)) {
      es_valida=false;
    }
  }
  return es_valida;
}

//precondicion: los valores que recibe deben ser positivos
//postcondicion: - (¿no hay porque el nombre es claro?)
int calcular_distancia_manhattan(coordenada_t posicion1, coordenada_t posicion2){

  int distancia_filas=posicion2.fila-posicion1.fila;
  int distancia_columnas=posicion2.columna-posicion1.columna;
  int distancia_total=0;

  //se aplica el modulo a las distancias para que sean siempre positivas
  if (distancia_filas<0) {
    distancia_filas=-distancia_filas;
  }

  if (distancia_columnas<0) {
    distancia_columnas=-distancia_columnas;
  }

  distancia_total=distancia_filas+distancia_columnas;
  return distancia_total;
}



//se fija si un movimiento es valido y en caso de serlo
//lo introduce dentro del vector movimientos_validos_snitch
void establecer_movimientos_validos(movimiento_valido_t movimientos_validos[CANTIDAD_DESPLAZAMIENTOS_POSIBLES_DE_SNITCH], int* tope_movimientos_validos, char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t juego, coordenada_t posicion) {

  if (es_posicion_valida(campo, posicion, juego)) {
    movimientos_validos[*tope_movimientos_validos].posicion=posicion;
    movimientos_validos[*tope_movimientos_validos].distancia_del_jugador=calcular_distancia_manhattan(juego.posicion_jugador, posicion);
    (*tope_movimientos_validos)++;
  }
}


//devuelve por referencia los dos movimientos cuyas posiciones
//tienen asociadas las dos mayores distancias
void determinar_movimientos_mas_distantes(movimiento_valido_t movimientos[] ,movimiento_valido_t* movimiento_mas_distante, movimiento_valido_t* segundo_movimiento_mas_distante, int tope_movimientos) {

  (*movimiento_mas_distante)=movimientos[0];

  if (tope_movimientos>1) {
    (*segundo_movimiento_mas_distante)=movimientos[1];

    for (int i = 1; i < tope_movimientos; i++) {
      if (movimientos[i].distancia_del_jugador>(*movimiento_mas_distante).distancia_del_jugador) {
        (*segundo_movimiento_mas_distante)=(*movimiento_mas_distante);
        (*movimiento_mas_distante)=movimientos[i];
      }else if(movimientos[i].distancia_del_jugador>(*segundo_movimiento_mas_distante).distancia_del_jugador){
        (*segundo_movimiento_mas_distante)=movimientos[i];
      }
    }
  }
}


void eliminar_elemento(coordenada_t obstaculos[], int posicion_elemento, int* tope){

  for (int i = posicion_elemento; i < (*tope)-1; i++) {
    obstaculos[i]=obstaculos[i+1];
  }
  (*tope)-=1;
}


//Devuelve el índice del obstáculo que halla chocado al jugador,
//debe indicársele a la función si se evalúa un choque con un
//dementor o con una bludger
int elemento_que_choca_jugador(juego_t juego, char obstaculo){

  bool hay_choque=false;
  int elemento_chocado=0;

  if (obstaculo==BLUDGER) {
    for (int i = 0; i < juego.bludgers_en_juego; i++) {
      if ((juego.casa!=SLYTHERIN)&&(juego.posicion_jugador.fila==juego.posicion_bludgers[i].fila)&&(juego.posicion_jugador.columna==juego.posicion_bludgers[i].columna)) {
        hay_choque=true;
        elemento_chocado=i;
      }
    }
  }

  if (obstaculo==DEMENTOR) {
    for (int i = 0; i < juego.dementores_en_juego; i++) {
      //(juego.posicion_jugador.fila==juego.posicion_dementores[i].fila)&&(juego.posicion_jugador.columna==juego.posicion_dementores[i].columna)
      if (posiciones_son_iguales(juego.posicion_jugador, juego.posicion_dementores[i])) {
        hay_choque=true;
        elemento_chocado=i;
      }
    }
  }

  if (!hay_choque){
    return NO_HAY_CHOQUE;
  }

  return elemento_chocado;
}


//precondición: las posiciones deben pertenecer a movimientos válidos
// ya que si no lo son puede devolver una posición no permitida
//postcondición: la posicioón que priorizará la snitch de las dos enviadas
coordenada_t determinar_posicion_prioritaria(coordenada_t posicion1, coordenada_t posicion2){

  coordenada_t posicion_prioritaria;

  if (posicion1.fila<posicion2.fila) {
    posicion_prioritaria=posicion1;
  }else if (posicion1.fila>posicion2.fila) {
    posicion_prioritaria=posicion2;
  }else{
    if (posicion1.columna<posicion2.columna) {
      posicion_prioritaria=posicion1;
    }else{
      posicion_prioritaria=posicion2;
    }
  }

  return posicion_prioritaria;
}

//si la posicion enviada está fuera de la matriz campo,
//la mete adentro de este
void introducir_dentro_del_campo(coordenada_t* posicion_objeto){

  if ((*posicion_objeto).fila<PRIMERA_FILA_CAMPO) {
    (*posicion_objeto).fila=PRIMERA_FILA_CAMPO;
  }

  if ((*posicion_objeto).columna<PRIMERA_COLUMNA_CAMPO) {
    (*posicion_objeto).columna=PRIMERA_COLUMNA_CAMPO;
  }

  if ((*posicion_objeto).fila>ULTIMA_FILA_CAMPO) {
    (*posicion_objeto).fila=ULTIMA_FILA_CAMPO;
  }

  if ((*posicion_objeto).columna>ULTIMA_COLUMNA_CAMPO) {
    (*posicion_objeto).columna=ULTIMA_COLUMNA_CAMPO;
  }
}

bool esta_en_submatriz_ravenclaw(coordenada_t posicion_objeto, juego_t juego){

  bool esta_en_submatriz=false;
  coordenada_t minima_coordenada_submatriz={juego.posicion_jugador.fila-1,juego.posicion_jugador.columna-1};
  coordenada_t maxima_coordenada_submatriz={juego.posicion_jugador.fila+1,juego.posicion_jugador.columna+1};

  introducir_dentro_del_campo(&minima_coordenada_submatriz);
  introducir_dentro_del_campo(&maxima_coordenada_submatriz);

  //se ve si la posicion está dentro de la submatriz
  for (int i= minima_coordenada_submatriz.fila; i <= maxima_coordenada_submatriz.fila; i++) {
    for (int j = minima_coordenada_submatriz.columna; j <= maxima_coordenada_submatriz.columna; j++) {
      if ((posicion_objeto.fila==i)&&(posicion_objeto.columna==j)) {
        esta_en_submatriz=true;
      }
    }
  }
  return esta_en_submatriz;
}



//precondicion: el movimiento otorgado debe ser un movimiento válido
//y el jugador debe estar dentro del campo de juego
//postcondicion: devuelve si el jugador está o no dentro del campo
//haciendo ese movimiento
bool esta_dentro_del_campo(char movimiento, coordenada_t posicion_jugador){

  bool esta_dentro=true;

  if ((posicion_jugador.fila==ULTIMA_FILA_CAMPO)&&(movimiento==ABAJO)) {
      esta_dentro=false;
  }

  if ((posicion_jugador.fila==PRIMERA_FILA_CAMPO)&&(movimiento==ARRIBA)) {
      esta_dentro=false;
  }

  if ((posicion_jugador.columna==PRIMERA_COLUMNA_CAMPO)&&(movimiento==IZQUIERDA)) {
      esta_dentro=false;
  }

  if ((posicion_jugador.columna==ULTIMA_COLUMNA_CAMPO)&&(movimiento==DERECHA)) {
      esta_dentro=false;
  }

  return esta_dentro;
}

//preciondiciones: -
//postcondicion: devuelbe un booleano que indica si es
//una tecla valida(verdadero cuando no está habilitada y
//falso cuando está habilitada)
bool es_tecla_habilitada(char movimiento){

  bool esta_habilitada=true;

  if ((movimiento!=ARRIBA)&&(movimiento!=ABAJO)&&(movimiento!=IZQUIERDA)&&(movimiento!=DERECHA)) {
    esta_habilitada=false;
  }
  return esta_habilitada;
}

void dejar_espacio(){

  for (int i = 0; i < 100; i++) {
    printf("\n");
  }
}


void actualizar_matriz(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t juego){

  for (int i = 0; i < CANTIDAD_FILAS; i++) {
    for (int j = 0; j < CANTIDAD_COLUMNAS; j++) {
      campo[i][j]=' ';
    }
  }

  for (int l = 0; l < juego.bludgers_en_juego; l++) {
    campo[juego.posicion_bludgers[l].fila][juego.posicion_bludgers[l].columna]=BLUDGER;
  }

  campo[juego.posicion_snitch.fila][juego.posicion_snitch.columna]= SNITCH;
  campo[juego.posicion_jugador.fila][juego.posicion_jugador.columna]= JUGADOR;

  for (int m = 0; m < juego.dementores_en_juego; m++) {
    campo[juego.posicion_dementores[m].fila][juego.posicion_dementores[m].columna]= DEMENTOR;
  }
}


void imprimir_matriz(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS]){

  for (int i = 0; i < CANTIDAD_COLUMNAS+2; i++) {
    printf("*");
  }

  printf("\n");

  for (int i = 0; i < CANTIDAD_FILAS; i++) {
    printf("*");
    for (int j = 0; j < CANTIDAD_COLUMNAS; j++) {
      printf("%c", campo[i][j]);
    }
    printf("*\n");
  }

  for (int i = 0; i < CANTIDAD_COLUMNAS+2; i++) {
    printf("*");
  }

  printf("\n");
}


void inicializar_juego(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], char casa, juego_t *juego){

  //MODULARIZAR

  (*juego).posicion_jugador.fila= CENTRO_FILAS;
  (*juego).posicion_jugador.columna= CENTRO_COLUMNAS;
  (*juego).resistencia= RESISTENCIA_INICIAL;
  (*juego).casa= casa;

  (*juego).direccion= HACIA_DERECHA;
  (*juego).bludgers_en_juego=  CANTIDAD_INICIAL_BLUDGERS;

  //inicializacion de bludgers
  for (int i = 0; i < CANTIDAD_INICIAL_BLUDGERS; i++) {
    (*juego).posicion_bludgers[i].fila=i*DISTANCIA_ENTRE_BLUDGERS+2;
    (*juego).posicion_bludgers[i].columna= COLUMNA_INICIAL_BLUDGERS;
  }

  (*juego).dementores_en_juego= CANTIDAD_INICIAL_DEMENTORES;

  //inicializacion de dementores
  (*juego).posicion_dementores[0].fila=FILA_1_DEMENTORES;
  (*juego).posicion_dementores[0].columna=COLUMNA_1_DEMENTORES;

  (*juego).posicion_dementores[1].fila=FILA_1_DEMENTORES;
  (*juego).posicion_dementores[1].columna=COLUMNA_2_DEMENTORES;

  (*juego).posicion_dementores[2].fila=FILA_2_DEMENTORES;
  (*juego).posicion_dementores[2].columna=COLUMNA_1_DEMENTORES;

  (*juego).posicion_dementores[3].fila=FILA_2_DEMENTORES;
  (*juego).posicion_dementores[3].columna=COLUMNA_2_DEMENTORES;

  (*juego).estado=EN_EJECUCION;

  (*juego).posicion_snitch=posicion_inicial_snitch();
}

char pedir_movimiento(coordenada_t posicion_jugador){

  char movimiento;

  do {
    printf("Inserte movimiento:");
    scanf(" %c", &movimiento);

    if (!(es_tecla_habilitada(movimiento))) {
      //arreglar doble impresion de esto
      //arreglar avance de mas de un espacio escribiendo mas de un caracter
      printf("Tecla incorrecta, por favor ingrese 'w', 'a','s' o 'd'.");
    }

    if (!(esta_dentro_del_campo(movimiento, posicion_jugador))) {
      printf("El movimiento lo deja fuera del campo de juego, por favor ingrese otra direccion");
    }
  } while(!(es_tecla_habilitada(movimiento))||(!(esta_dentro_del_campo(movimiento, posicion_jugador)))/*&&(strlen(movimiento)>1)*//*&&(agregar validacion para ver si el movimiento lo deja afuera de la matriz)*/);

  return movimiento;
}

void mover_jugador(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], char direccion, juego_t *juego){

  int bludger_chocada=0;
  int dementor_chocado=0;

  switch (direccion) {
    case ARRIBA:
    (*juego).posicion_jugador.fila--;
    break;

    case ABAJO:
    (*juego).posicion_jugador.fila++;
    break;

    case IZQUIERDA:
    (*juego).posicion_jugador.columna--;
    break;

    case DERECHA:
    (*juego).posicion_jugador.columna++;
    break;
  }

  (*juego).resistencia--;

  if (elemento_que_choca_jugador((*juego), DEMENTOR)!=NO_HAY_CHOQUE) {
    if ((*juego).casa==GRYFFINDOR) {
      dementor_chocado=elemento_que_choca_jugador((*juego), DEMENTOR);
      eliminar_elemento((*juego).posicion_dementores, dementor_chocado, &((*juego).dementores_en_juego));
    }else{
      (*juego).resistencia=0;
    }
  }

  if (elemento_que_choca_jugador((*juego), BLUDGER)!=NO_HAY_CHOQUE) {
    bludger_chocada=elemento_que_choca_jugador((*juego), BLUDGER);
    (*juego).resistencia-=REDUCCION_RESISTENCIA_POR_CHOQUE;
    eliminar_elemento((*juego).posicion_bludgers, bludger_chocada, &((*juego).bludgers_en_juego));
  }


  //((*juego).posicion_jugador.fila==(*juego).posicion_snitch.fila)&&((*juego).posicion_jugador.columna==(*juego).posicion_snitch.columna)
  /*if (posiciones_son_iguales((*juego).posicion_jugador, (*juego).posicion_snitch)) {
    (*juego).estado=JUGADOR_GANO;
  }

  if ((*juego).casa==RAVENCLAW) {
    if (esta_en_submatriz_ravenclaw((*juego).posicion_snitch,*juego)) {
      (*juego).estado=JUGADOR_GANO;
    }
  }*/

  if ((*juego).resistencia<0) {
    (*juego).resistencia=0;
  }

  /*if (((*juego).resistencia==0)&&((*juego).estado!=JUGADOR_GANO)) {
      (*juego).estado=JUGADOR_PERDIO;
  }*/

  actualizar_matriz(campo, *juego);
}

void mover_snitch(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t *juego){

  //MODULARIZAR

  if (!finalizo_juego(juego)) {

    //se agregan estas variables para que no queden argumenos locales
    //demasiado largos
    coordenada_t posicion_definitiva;
    movimiento_valido_t movimiento_mas_distante;
    movimiento_valido_t segundo_movimiento_mas_distante;

    coordenada_t coordenadas_snitch= (*juego).posicion_snitch;
    coordenada_t coordenadas_jugador= (*juego).posicion_jugador;
    coordenada_t coordenadas_arriba_izquierda_snitch= {(*juego).posicion_snitch.fila-1,(*juego).posicion_snitch.columna-1};
    coordenada_t coordenadas_arriba_derecha_snitch= {(*juego).posicion_snitch.fila-1,(*juego).posicion_snitch.columna+1};
    coordenada_t coordenadas_abajo_izquierda_snitch= {(*juego).posicion_snitch.fila+1,(*juego).posicion_snitch.columna-1};
    coordenada_t coordenadas_abajo_derecha_snitch={(*juego).posicion_snitch.fila+1,(*juego).posicion_snitch.columna+1};


    movimiento_valido_t movimientos_validos_snitch[CANTIDAD_DESPLAZAMIENTOS_POSIBLES_DE_SNITCH];
    int tope_movimientos_validos=0;

    int distancia_jugador_a_snitch=calcular_distancia_manhattan(coordenadas_jugador, coordenadas_snitch);


    if (distancia_jugador_a_snitch<=DISTANCIA_MAXIMA_JUGADOR_A_SNITCH_CON_MOVIMIENTO) {

      //establece la prioridad de movimiento de la snitch como si
      //todas las distancias de las posiciones al jugador fueran las mismas

      establecer_movimientos_validos(movimientos_validos_snitch, &tope_movimientos_validos, campo, *juego, coordenadas_arriba_izquierda_snitch);
      establecer_movimientos_validos(movimientos_validos_snitch, &tope_movimientos_validos, campo, *juego, coordenadas_arriba_derecha_snitch);
      establecer_movimientos_validos(movimientos_validos_snitch, &tope_movimientos_validos, campo, *juego, coordenadas_abajo_izquierda_snitch);
      establecer_movimientos_validos(movimientos_validos_snitch, &tope_movimientos_validos, campo, *juego, coordenadas_abajo_derecha_snitch);


      //se buscan las posiciones asociadas a los dos lugares mas distantes
      //en los que se podrá ubicar la snitch, asumiendo que el primer elemento
      //es el mayor y el segundo elemento el segundo mayor, luego se corrobora

      if (tope_movimientos_validos>0) {

        determinar_movimientos_mas_distantes(movimientos_validos_snitch ,&movimiento_mas_distante, &segundo_movimiento_mas_distante, tope_movimientos_validos);

        if ((movimiento_mas_distante.distancia_del_jugador!=segundo_movimiento_mas_distante.distancia_del_jugador)) {
          posicion_definitiva=movimiento_mas_distante.posicion;
        }

        if (movimiento_mas_distante.distancia_del_jugador==segundo_movimiento_mas_distante.distancia_del_jugador) {
          posicion_definitiva= determinar_posicion_prioritaria(movimiento_mas_distante.posicion, segundo_movimiento_mas_distante.posicion);
        }
        (*juego).posicion_snitch=posicion_definitiva;
      }
    }

    actualizar_matriz(campo, *juego);

    //PARA CORRECTOR: para ver si los movimientos son validos se usará la función
    //es_posicion_valida . EL código está comentado porque como todavía no están usadas
    //las variables definidas tira error si se intentan compilar junto con el resto del código

  }
}

void mover_bludgers(char campo[CANTIDAD_FILAS][CANTIDAD_COLUMNAS], juego_t *juego){

  if (!finalizo_juego(juego)) {

      int bludger_chocada=0;
      int adicion_posicion_bludger=determinar_sentido_bludgers(juego);


      for (int i = 0; i < (*juego).bludgers_en_juego; i++) {
        (*juego).posicion_bludgers[i].columna+=adicion_posicion_bludger;
      }

      //ver si se puede pasar a funcion
      if (elemento_que_choca_jugador((*juego), BLUDGER)!=NO_HAY_CHOQUE) {
        bludger_chocada=elemento_que_choca_jugador((*juego), BLUDGER);
        (*juego).resistencia-=REDUCCION_RESISTENCIA_POR_CHOQUE;
        eliminar_elemento((*juego).posicion_bludgers, bludger_chocada, &((*juego).bludgers_en_juego));
      }

      //ver si se puede pasar a funcion (esta tambien en mover jugador)
      if ((*juego).resistencia<0) {
        (*juego).resistencia=0;
      }

      /*if (((*juego).resistencia==0)&&((*juego).estado!=JUGADOR_GANO)) {
      (*juego).estado=JUGADOR_PERDIO;
    }*/

    actualizar_matriz(campo, *juego);

  }
}

coordenada_t posicion_inicial_snitch(){

  coordenada_t centro_del_campo={CENTRO_FILAS, CENTRO_COLUMNAS};
  coordenada_t posicion_inicial;

  srand((unsigned int)clock());

  do {
    posicion_inicial.fila=rand()%ULTIMA_FILA_CAMPO;
    posicion_inicial.columna=rand()%ULTIMA_COLUMNA_CAMPO;
  } while(calcular_distancia_manhattan(posicion_inicial, centro_del_campo)<5);

  return posicion_inicial;
}

bool finalizo_juego(juego_t *juego){

  //((*juego).posicion_jugador.fila==(*juego).posicion_snitch.fila)&&((*juego).posicion_jugador.columna==(*juego).posicion_snitch.columna)
  if (posiciones_son_iguales((*juego).posicion_jugador, (*juego).posicion_snitch)) {
    (*juego).estado=JUGADOR_GANO;
    return true;
  }

  if ((*juego).casa==RAVENCLAW) {
    if (esta_en_submatriz_ravenclaw((*juego).posicion_snitch,*juego)) {
      (*juego).estado=JUGADOR_GANO;
    }
  }

  if (((*juego).resistencia==0)&&((*juego).estado!=JUGADOR_GANO)) {
      (*juego).estado=JUGADOR_PERDIO;
      return true;
  }

  return false;
}

void mostrar_resultado(juego_t juego){

  if (juego.estado==JUGADOR_PERDIO) {
    printf("Perdió, se acabó la resistencia\n");
  }

  if (juego.estado==JUGADOR_GANO) {
    printf("Ganó, pudo atrapar la snitch\n");
  }
}
