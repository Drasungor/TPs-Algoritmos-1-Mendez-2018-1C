#ifndef SOMBRERO_H
#define SOMBRERO_H

//No se necesitan valores para invocar la función.
//Una vez ejecutada pide valores de 0 a 10 para 5 atributos y,
//en base a los resultados, devuelve la inicial de la casa a la
//que se pertenece

char obtener_casa();


#endif
