#include <stdio.h>


#define FALSE 0
#define TRUE 1

//las funciones void se encargan de obtener el valor
//de un atributo específico y se aseguran de que este esté
//dentro del rango pedido

void determinar_fuerza(int* indice_fuerza) {
  do {
    printf("fuerza: ");
    scanf("%i", indice_fuerza);
    if ((*indice_fuerza<0)||(*indice_fuerza>10)) {
      printf("Valor del atributo fuera del rango asignado,\n");
      printf("por favor ingrese un número de 0 a 10\n");
    }
  } while((*indice_fuerza<0)||(*indice_fuerza>10));
}

void determinar_valor(int* indice_valor) {
  do {
    printf("Valor: ");
    scanf("%i", indice_valor);
    if ((*indice_valor<0)||(*indice_valor>10)) {
      printf("Valor del atributo fuera del rango asignado,\n");
      printf("por favor ingrese un número de 0 a 10\n");
    }
  } while((*indice_valor<0)||(*indice_valor>10));
}

void determinar_inteligencia(int* indice_inteligencia) {
  do {
    printf("Inteligencia: ");
    scanf("%i", indice_inteligencia);
    if ((*indice_inteligencia<0)||(*indice_inteligencia>10)) {
      printf("Valor del atributo fuera del rango asignado,\n");
      printf("por favor ingrese un número de 0 a 10\n");
    }
  } while((*indice_inteligencia<0)||(*indice_inteligencia>10));
}

void determinar_ingenio(int* indice_ingenio) {
  do {
    printf("Ingengio: ");
    scanf("%i", indice_ingenio);
    if ((*indice_ingenio<0)||(*indice_ingenio>10)) {
      printf("Valor del atributo fuera del rango asignado,\n");
      printf("por favor ingrese un número de 0 a 10\n");
    }
  } while((*indice_ingenio<0)||(*indice_ingenio>10));
}

void determinar_dedicacion(int* indice_dedicacion) {
  do {
    printf("Dedicacion: ");
    scanf("%i", indice_dedicacion);
    if ((*indice_dedicacion<0)||(*indice_dedicacion>10)) {
      printf("Valor del atributo fuera del rango asignado,\n");
      printf("por favor ingrese un número de 0 a 10\n");
    }
  } while((*indice_dedicacion<0)||(*indice_dedicacion>10));
}

int main() {

  int fuerza, valor, inteligencia, ingengio, dedicacion;
  int fuerza_es_super_atributo, valor_es_super_atributo, inteligencia_es_super_atributo, ingenio_es_super_atributo, dedicacion_es_super_atributo;
  int cantidad_super_atributos=0;

  fuerza_es_super_atributo = FALSE;
  valor_es_super_atributo = FALSE;
  inteligencia_es_super_atributo = FALSE;
  ingenio_es_super_atributo = FALSE;
  dedicacion_es_super_atributo = FALSE;

  printf("Bienvenido al sombrero seleccionador, para que su casa sea\n");
  printf("elegida, deberá introducir valores de 0 a 10 para los\n");
  printf("atributos que serán presentados, no debe haber más de dos\n");
  printf("supe ratributos, que son aquellos con un valor de 9 o 10:\n");

  do {
    //codigo para pedido de atributos y determinación de super atributos
    cantidad_super_atributos=0;

    determinar_fuerza(&fuerza);

    determinar_valor(&valor);

    determinar_inteligencia(&inteligencia);

    determinar_ingenio(&ingengio);

    determinar_dedicacion(&dedicacion);

    if (fuerza>8) {
      fuerza_es_super_atributo=TRUE;
      cantidad_super_atributos++;
    }

    if (valor>8) {
      valor_es_super_atributo=TRUE;
      cantidad_super_atributos++;
    }

    if (ingengio>8) {
      ingenio_es_super_atributo=TRUE;
      cantidad_super_atributos++;
    }

    if (dedicacion>8) {
      dedicacion_es_super_atributo=TRUE;
      cantidad_super_atributos++;
    }

    if (inteligencia>8) {
      inteligencia_es_super_atributo=TRUE;
      cantidad_super_atributos++;
    }

    if (cantidad_super_atributos>2) {
      printf("Superó la cantidad de super atributos, los suyos fueron:\n");
      if (fuerza_es_super_atributo) {
        printf("Fuerza\n");
      }
      if (valor_es_super_atributo) {
        printf("Valor\n");
      }
      if (ingenio_es_super_atributo) {
        printf("Ingenio\n");
      }
      if (dedicacion_es_super_atributo) {
        printf("Dedicacion\n");
      }
      if (inteligencia_es_super_atributo) {
        printf("Inteligencia\n");
      }

      fuerza_es_super_atributo = FALSE;
      valor_es_super_atributo = FALSE;
      inteligencia_es_super_atributo = FALSE;
      ingenio_es_super_atributo = FALSE;
      dedicacion_es_super_atributo = FALSE;

      printf("Por favor, reingrese sus atributos:\n");
    }

  } while(cantidad_super_atributos>2);

  //se analizan los valores y se indica la casa a la
  //que se pertenece en base a eso

  if ((fuerza>8)&&(valor>8)&&(ingengio<5)) {
    printf("Su casa es Gryffindor\n");
  }
  else if ((inteligencia>8)&&(ingengio>8)) {
    printf("Su casa es Ravenclaw\n");
  }
  else if ((inteligencia>5)&&(inteligencia<8)&&(ingengio>8)) {
    printf("Su casa es Slytherin\n");
  }
  else {
    printf("Su casa es Hufflepuff\n");
  }

  return 0;
}
