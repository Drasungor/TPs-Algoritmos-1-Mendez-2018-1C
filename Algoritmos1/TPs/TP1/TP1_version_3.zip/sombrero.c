#include <stdio.h>

#define FALSE 0
#define TRUE 1
#define LIMITE_ATRIBUTO_NORMAL 8
#define MAXIMA_CANTIDAD_SUPERATRIBUTOS 2
#define STRING_FUERZA "Fuerza"
#define STRING_VALOR "Valor"
#define STRING_INTELIGENCIA "Inteligencia"
#define STRING_INGENIO "Ingenio"
#define STRING_DEDICACION "Dedicacion"


int contar_super_atributos (int cantidad_fuerza, int cantidad_valor, int cantidad_ingenio, int cantidad_dedicacion, int cantidad_inteligencia){
  int contador_super_atributos=0;

  if (cantidad_fuerza>LIMITE_ATRIBUTO_NORMAL) {
    contador_super_atributos++;
  }

  if (cantidad_valor>LIMITE_ATRIBUTO_NORMAL) {
    contador_super_atributos++;
  }

  if (cantidad_ingenio>LIMITE_ATRIBUTO_NORMAL) {
    contador_super_atributos++;
  }

  if (cantidad_dedicacion>LIMITE_ATRIBUTO_NORMAL) {
    contador_super_atributos++;
  }

  if (cantidad_inteligencia>LIMITE_ATRIBUTO_NORMAL) {
    contador_super_atributos++;
  }

  return contador_super_atributos;
}



//en los sigueintes 3 void
//se analizan los valores de los atributos
// y se indica la casa a la
//que se pertenece en base a eso

void es_slytherin(int indice_final_inteligencia_asignacion_slytherin, int indice_final_ingenio_asignacion_slytherin) {
  if ((indice_final_inteligencia_asignacion_slytherin>5)&&(indice_final_inteligencia_asignacion_slytherin<8)&&(indice_final_ingenio_asignacion_slytherin>8)) {
    printf("Su casa es Slytherin\n");
  }
  else {
    printf("Su casa es Hufflepuff\n");
  }
}

void es_ravenclaw(int indice_final_inteligencia_asignacion_ravenclaw, int indice_final_ingenio_asignacion_ravenclaw) {
  if ((indice_final_inteligencia_asignacion_ravenclaw>8)&&(indice_final_ingenio_asignacion_ravenclaw>8)) {
    printf("Su casa es Ravenclaw\n");
  }
  else {
    es_slytherin(indice_final_inteligencia_asignacion_ravenclaw, indice_final_ingenio_asignacion_ravenclaw);
  }
}

void es_gryffindor(int indice_final_fuerza_asignacion_gryffindor, int indice_final_valor_asignacion_gryffindor, int indice_final_ingenio_asignacion_gryffindor, int indice_final_inteligencia_asignacion_gryffindor) {
  if ((indice_final_fuerza_asignacion_gryffindor>8)&&(indice_final_valor_asignacion_gryffindor>8)&&(indice_final_ingenio_asignacion_gryffindor<5)) {
    printf("Su casa es Gryffindor\n");
  }
  else {
    es_ravenclaw(indice_final_inteligencia_asignacion_gryffindor, indice_final_ingenio_asignacion_gryffindor);
  }
}

void listar_super_atributos(int numero_fuerza, int numero_valor, int numero_ingenio, int numero_dedicacion, int numero_inteligencia) {

  if (numero_fuerza>LIMITE_ATRIBUTO_NORMAL) {
    printf("Fuerza\n");
  }
  if (numero_valor>LIMITE_ATRIBUTO_NORMAL) {
    printf("Valor\n");
  }
  if (numero_ingenio>LIMITE_ATRIBUTO_NORMAL) {
    printf("Ingenio\n");
  }
  if (numero_dedicacion>LIMITE_ATRIBUTO_NORMAL) {
    printf("Dedicacion\n");
  }
  if (numero_inteligencia>LIMITE_ATRIBUTO_NORMAL) {
    printf("Inteligencia\n");
  }
}


//la funcion se encarga de obtener el valor
//de un atributo específico y se asegura de que este esté
//dentro del rango pedido
void determinar__atributo(int* indice_atributo, char nombre_atributo[]){
  do {
    printf("%s:", nombre_atributo);
    scanf("%i", indice_atributo);
    if ((*indice_atributo<0)||(*indice_atributo>10)) {
      printf("Valor del atributo fuera del rango asignado,\n");
      printf("por favor ingrese un número de 0 a 10\n");
    }
  } while((*indice_atributo<0)||(*indice_atributo>10));

}


int main() {

  int fuerza, valor, inteligencia, ingenio, dedicacion;
  int cantidad_super_atributos=0;

  printf("Bienvenido al sombrero seleccionador, para que su casa sea\n");
  printf("elegida, deberá introducir valores de 0 a 10 para los\n");
  printf("atributos que serán presentados. No debe haber más de dos\n");
  printf("super atributos, que son aquellos con un valor de 9 o 10:\n");

  do {
    //codigo para pedido de atributos y determinación de super atributos

    determinar__atributo(&fuerza, STRING_FUERZA);

    determinar__atributo(&valor, STRING_VALOR);

    determinar__atributo(&inteligencia, STRING_INTELIGENCIA);

    determinar__atributo(&ingenio, STRING_INGENIO);

    determinar__atributo(&dedicacion, STRING_DEDICACION);

    cantidad_super_atributos = contar_super_atributos(fuerza, valor, ingenio, dedicacion, inteligencia);

    if (cantidad_super_atributos>MAXIMA_CANTIDAD_SUPERATRIBUTOS) {
      printf("Superó la cantidad de super atributos, los suyos fueron:\n");
      listar_super_atributos(fuerza, valor, ingenio, dedicacion, inteligencia);
      printf("Por favor, reingrese sus atributos:\n");
    }

  } while(cantidad_super_atributos>2);

  es_gryffindor(fuerza, valor, ingenio, inteligencia);

  return 0;
}
