#include <stdio.h>
#include <stdbool.h>


#define LIMITE_ATRIBUTO_NORMAL 8
#define MAXIMA_CANTIDAD_SUPERATRIBUTOS 2
#define STRING_FUERZA "Fuerza"
#define STRING_VALOR "Valor"
#define STRING_INTELIGENCIA "Inteligencia"
#define STRING_INGENIO "Ingenio"
#define STRING_DEDICACION "Dedicacion"


int contar_super_atributos (int cantidad_fuerza, int cantidad_valor, int cantidad_ingenio, int cantidad_dedicacion, int cantidad_inteligencia){
  int contador_super_atributos=0;

  if (cantidad_fuerza>LIMITE_ATRIBUTO_NORMAL) {
    contador_super_atributos++;
  }

  if (cantidad_valor>LIMITE_ATRIBUTO_NORMAL) {
    contador_super_atributos++;
  }

  if (cantidad_ingenio>LIMITE_ATRIBUTO_NORMAL) {
    contador_super_atributos++;
  }

  if (cantidad_dedicacion>LIMITE_ATRIBUTO_NORMAL) {
    contador_super_atributos++;
  }

  if (cantidad_inteligencia>LIMITE_ATRIBUTO_NORMAL) {
    contador_super_atributos++;
  }

  return contador_super_atributos;
}



//en los sigueintes 3 bool
//se analizan los valores de los atributos
// y se ve si se pertenece a la casa cuyas
//condiciones están siendo comparadas

bool es_slytherin(int grado_fuerza, int grado_valor, int grado_ingenio, int grado_inteligencia, int grado_dedicacion) {
  return (grado_inteligencia>5)&&(grado_inteligencia<8)&&(grado_ingenio>8);
}

bool es_ravenclaw(int medida_fuerza, int medida_valor, int medida_ingenio, int medida_inteligencia, int medida_dedicacion) {
      return (medida_ingenio>8)&&(medida_inteligencia>8);
}

bool es_gryffindor(int magnitud_fuerza, int magnitud_valor, int magnitud_ingenio, int magnitud_inteligencia, int magnitud_dedicacion) {
  return (magnitud_fuerza>8)&&(magnitud_valor>8)&&(magnitud_ingenio<5);
}

void mostrar_casa(int indice_atributo_fuerza, int indice_atributo_valor,int indice_atributo_ingenio, int indice_atributo_inteligencia, int indice_atributo_dedicacion){
  bool pertenece_a_gryffindor = es_gryffindor(indice_atributo_fuerza, indice_atributo_valor, indice_atributo_ingenio, indice_atributo_inteligencia, indice_atributo_dedicacion);
  bool pertenece_a_ravenclaw = es_ravenclaw(indice_atributo_fuerza, indice_atributo_valor, indice_atributo_ingenio, indice_atributo_inteligencia, indice_atributo_dedicacion);
  bool pertenece_a_slytherin = es_slytherin(indice_atributo_fuerza, indice_atributo_valor, indice_atributo_ingenio, indice_atributo_inteligencia, indice_atributo_dedicacion);

  if (pertenece_a_gryffindor) {
    printf("Su casa es Gryffindor\n");
  }
  else if (pertenece_a_ravenclaw) {
    printf("Su casa es Ravenclaw\n");
  }
  else if (pertenece_a_slytherin) {
    printf("Su casa es Slytherin\n");
  }
  else {
    printf("Su casa es Hufflepuff\n");
  }
}

void listar_super_atributos(int numero_fuerza, int numero_valor, int numero_ingenio, int numero_dedicacion, int numero_inteligencia) {

  if (numero_fuerza>LIMITE_ATRIBUTO_NORMAL) {
    printf("Fuerza\n");
  }
  if (numero_valor>LIMITE_ATRIBUTO_NORMAL) {
    printf("Valor\n");
  }
  if (numero_ingenio>LIMITE_ATRIBUTO_NORMAL) {
    printf("Ingenio\n");
  }
  if (numero_dedicacion>LIMITE_ATRIBUTO_NORMAL) {
    printf("Dedicacion\n");
  }
  if (numero_inteligencia>LIMITE_ATRIBUTO_NORMAL) {
    printf("Inteligencia\n");
  }
}


//la funcion se encarga de obtener el valor
//de un atributo específico y se asegura de que este esté
//dentro del rango pedido
void determinar__atributo(int* indice_atributo, char nombre_atributo[]){
  do {
    printf("%s:", nombre_atributo);
    scanf("%i", indice_atributo);
    if ((*indice_atributo<0)||(*indice_atributo>10)) {
      printf("Valor del atributo fuera del rango asignado,\n");
      printf("por favor ingrese un número de 0 a 10\n");
    }
  } while((*indice_atributo<0)||(*indice_atributo>10));

}


int main() {

  int fuerza, valor, inteligencia, ingenio, dedicacion;
  int cantidad_super_atributos=0;

  printf("Bienvenido al sombrero seleccionador, para que su casa sea\n");
  printf("elegida, deberá introducir valores de 0 a 10 para los\n");
  printf("atributos que serán presentados. No debe haber más de dos\n");
  printf("super atributos, que son aquellos con un valor de 9 o 10:\n");

  do {
    //codigo para pedido de atributos y determinación de super atributos

    determinar__atributo(&fuerza, STRING_FUERZA);

    determinar__atributo(&valor, STRING_VALOR);

    determinar__atributo(&inteligencia, STRING_INTELIGENCIA);

    determinar__atributo(&ingenio, STRING_INGENIO);

    determinar__atributo(&dedicacion, STRING_DEDICACION);

    cantidad_super_atributos = contar_super_atributos(fuerza, valor, ingenio, dedicacion, inteligencia);

    if (cantidad_super_atributos>MAXIMA_CANTIDAD_SUPERATRIBUTOS) {
      printf("Superó la cantidad de super atributos, los suyos fueron:\n");
      listar_super_atributos(fuerza, valor, ingenio, dedicacion, inteligencia);
      printf("Por favor, reingrese sus atributos:\n");
    }

  } while(cantidad_super_atributos>2);

  mostrar_casa(fuerza, valor, ingenio, inteligencia, dedicacion);

  return 0;
}
